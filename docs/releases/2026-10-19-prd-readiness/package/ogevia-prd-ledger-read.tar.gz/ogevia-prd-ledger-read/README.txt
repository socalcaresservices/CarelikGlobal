Ogevia production ledger read (report only). YELLOW: adds one temporary inbound rule (tcp 5432 from the admin host's /32) to the SHARED RDS security group, then removes and verifies it. Do not run without the owner's explicit approval.

Verify the file, then run (CloudShell, us-west-2, Node not required):
  cd ~ && mkdir -p ogevia-prd-read && tar -xzf ogevia-prd-ledger-read.tar.gz -C ogevia-prd-read && cd ogevia-prd-read/ogevia-prd-ledger-read
  sha256sum -c SHA256SUMS            # must print: ledger-prd-read.sh: OK
  OGEVIA_EXPECT_HOST_IP=10.20.132.179 bash ledger-prd-read.sh prd --host-ip
Type OPEN-5432-WINDOW when asked. Keep a second CloudShell session ready; if this one is lost run: bash ledger-prd-read.sh --restore-only
Expected end of output: "SECURITY GROUP: restored and verified identical to the original". Paste the whole output.
