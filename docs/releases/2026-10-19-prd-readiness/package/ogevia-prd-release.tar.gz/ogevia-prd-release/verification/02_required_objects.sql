-- READ ONLY. Required tables and API functions exist.
with required_tables(t) as (values
  ('app_users'), ('organizations'), ('organization_memberships'), ('permissions'), ('role_permissions'),
  ('caregiver_records'), ('clients'), ('services'), ('caregiver_assignments'), ('shifts'),
  ('shift_coverage_events'), ('client_authorizations'), ('service_visits'), ('visit_evidence'),
  ('visit_confirmations'), ('visit_corrections'), ('audit_events'), ('idempotency_records'),
  ('client_care_portals'), ('caregiver_availability_windows'), ('care_requests'), ('care_request_offers'),
  ('authorization_reservations'), ('care_notifications'), ('care_request_events'),
  ('availability_requests'), ('caregiver_availability_state'), ('shift_readiness_flags'), ('assignment_readiness_flags'),
  ('caregiver_service_approvals'), ('document_requirement_policies'), ('organization_readiness_settings'),
  ('readiness_setting_events'), ('availability_overrides'), ('scoring_rule_versions'), ('experience_tags'),
  ('caregiver_experience'), ('caregiver_experience_reviews'), ('client_experience_requirements'),
  ('caregiver_zip'), ('client_service_zip'), ('zip_centroids')
), required_functions(f) as (values
  ('begin_request'), ('get_active_service_visit'), ('list_assigned_visit_clients'),
  ('list_authorized_services_for_client'), ('start_ad_hoc_service_visit'), ('end_service_visit'),
  ('register_visit_evidence'), ('confirm_service_visit'), ('void_service_visit'),
  ('correct_service_visit'), ('amend_client_authorization'), ('list_service_visits'),
  ('list_visit_corrections'), ('list_billing_review_visits'),
  ('list_monthly_service_summary'), ('list_correction_history_report'),
  ('get_my_context'), ('get_visit_signature_evidence'), ('get_confirmation_replay'),
  ('public_create_care_request'), ('list_care_requests'), ('list_available_caregivers'),
  ('send_care_offer'), ('assign_care_request'), ('replace_my_availability'), ('list_my_care_opportunities'),
  ('revoke_client_care_portals'), ('public_list_care_requests'), ('close_missed_service_visit'),
  ('set_organization_letterhead'), ('get_availability'), ('request_availability_change'), ('review_availability_request'),
  ('set_availability_direct'), ('approve_caregiver_service'), ('revoke_caregiver_service'), ('bulk_approve_reviewed_services'),
  ('get_readiness_status'), ('activate_readiness_enforcement'), ('set_service_checks'), ('evaluate_assignment_readiness'),
  ('authorize_availability_override'), ('get_document_readiness'), ('set_requirement_policy'), ('match_caregivers'),
  ('match_caregivers_for_request'), ('list_accounts'), ('disable_account'), ('prepare_account_enable'), ('enable_account')
)
select 'table_exists:' || t as check_name,
       exists (select 1 from pg_tables where schemaname = 'ogevia' and tablename = t) as ok,
       null::text as detail
from required_tables
union all
select 'api_function_exists:' || f,
       exists (select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
               where n.nspname = 'ogevia_api' and p.proname = f), null
from required_functions
union all
select 'helper_function_exists:match_scheduled_shift_for_visit',
       exists (select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
               where n.nspname = 'ogevia' and p.proname = 'match_scheduled_shift_for_visit'), null
union all
select 'helper_function_exists:caregiver_has_current_shift',
       exists (select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
               where n.nspname = 'ogevia' and p.proname = 'caregiver_has_current_shift'), null
union all
select 'trigger_exists:service_visits_release_reservation',
       exists (select 1 from pg_trigger tg join pg_class c on c.oid = tg.tgrelid
               join pg_namespace n on n.oid = c.relnamespace
               where n.nspname = 'ogevia' and c.relname = 'service_visits'
                 and tg.tgname = 'service_visits_release_reservation'), null;
