import { MemoryRouter, useLocation } from "react-router-dom";
import {
  fireEvent,
  render,
  screen,
  waitFor,
  within,
} from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { afterEach, describe, expect, it, vi } from "vitest";
import { useOrganization } from "@/providers/organization-provider";
import { supabase } from "@/lib/supabase";
import { ServiceVerificationBackendContext, type ServiceVerificationBackend } from "@/lib/sv-backend";
import { ServiceVerificationReportsPage } from "./service-verification-reports-page";
import { EnvironmentProvider } from "@/aws/environment-marker";
import { AwsApiContext } from "@/aws/aws-workspace";
import type { AwsApiClient } from "@/lib/aws-api";
import { resolveEnvironmentMarker } from "@/aws/environment";
import { formatClockTime, formatVisitDate, toPacificWallTime } from "@/lib/service-verification";

vi.mock("@/providers/organization-provider", () => ({
  useOrganization: vi.fn(),
}));
vi.mock("@/lib/supabase", () => ({
  supabase: {
    rpc: vi.fn(),
    from: vi.fn(),
  },
}));

const mockedUseOrganization = vi.mocked(useOrganization);
const mockedRpc = vi.mocked(supabase.rpc);
const mockedFrom = vi.mocked(supabase.from);

const ORG_ID = "11111111-1111-4111-8111-111111111111";

const visitRow = {
  id: "22222222-2222-4222-8222-222222222222",
  visit_number: "SCS-V-20260801-4F7K",
  client_id: "33333333-3333-4333-8333-333333333333",
  client_code: "CL-ABC123",
  client_legal_name: "Jamie Smith",
  caregiver_user_id: "44444444-4444-4444-8444-444444444444",
  caregiver_name: "Jordan Rivera",
  service_id: "55555555-5555-4555-8555-555555555555",
  service_name: "Personal Care",
  service_date: "2026-08-01",
  time_in: "2026-08-01T13:00:00.000Z",
  time_out: "2026-08-01T14:00:00.000Z",
  worked_minutes: 60,
  verified_minutes: 60,
  billable_minutes: 60,
  status: "signed" as const,
  authorization_status: "within_authorization",
  signed_at: "2026-08-01T14:05:00.000Z",
  original_visit_id: null,
  is_corrected: false,
  month_to_date_before_minutes: 600,
  month_to_date_after_minutes: 660,
  remaining_minutes: 1740,
};

function renderPage() {
  const queryClient = new QueryClient({
    defaultOptions: { queries: { retry: false } },
  });
  return render(
    <MemoryRouter>
      <QueryClientProvider client={queryClient}>
        <ServiceVerificationReportsPage />
      </QueryClientProvider>
    </MemoryRouter>,
  );
}

async function openReport(name: RegExp) {
  const option = await screen.findByRole("option", { name });
  fireEvent.change(screen.getByLabelText("Report"), {
    target: { value: option.getAttribute("value") },
  });
}

function mockOrgLetterhead() {
  mockedFrom.mockImplementation((table: string) => {
    if (table === "clients") {
      const is = vi.fn().mockResolvedValue({
        data: [
          {
            id: visitRow.client_id,
            address_city: "Anaheim",
            address_state: "CA",
          },
        ],
        error: null,
      });
      const eq = vi.fn(() => ({ is }));
      return { select: vi.fn(() => ({ eq })) } as never;
    }
    const single = vi.fn().mockResolvedValue({
      data: {
        legal_name: "Acme Care LLC",
        display_name: "Acme Care",
        logo_url: null,
      },
      error: null,
    });
    const eq = vi.fn(() => ({ single }));
    return { select: vi.fn(() => ({ eq })) } as never;
  });
}

function LocationProbe() {
  const location = useLocation();
  return <p data-testid="location">{location.pathname}{location.search}</p>;
}

function renderPageWithLocation() {
  const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return render(
    <MemoryRouter initialEntries={["/service-verification/reports"]}>
      <QueryClientProvider client={queryClient}>
        <ServiceVerificationReportsPage />
        <LocationProbe />
      </QueryClientProvider>
    </MemoryRouter>,
  );
}

function allowEverything() {
  mockedUseOrganization.mockReturnValue({
    activeOrganizationId: ORG_ID,
    activeOrganization: { displayName: "Acme Care" },
    hasPermission: vi.fn(() => true),
  } as never);
  mockOrgLetterhead();
  mockedRpc.mockResolvedValue({ data: [visitRow], error: null } as never);
}

describe("ServiceVerificationReportsPage", () => {
  afterEach(() => {
    vi.clearAllMocks();
    vi.useRealTimers();
    window.history.replaceState({}, "", "/");
  });

  it("shows a not-available message without visits.read", () => {
    mockedUseOrganization.mockReturnValue({
      activeOrganizationId: ORG_ID,
      activeOrganization: { displayName: "Acme Care" },
      hasPermission: vi.fn(() => false),
    } as never);

    renderPage();

    expect(screen.getByText("Not available")).toBeInTheDocument();
    expect(mockedRpc).not.toHaveBeenCalled();
  });

  describe("export permission and audit (0069)", () => {
    const summaryRow = {
      clientId: "c1", clientCode: "TEST-C01", serviceId: "s1", serviceCode: "RSP", serviceName: "Respite",
      authorizationLineageId: "l1", authorizationPeriodStart: "2026-10-01", authorizationPeriodEnd: "2026-12-31",
      authorizedMinutes: 600, workedMinutes: 10, verifiedMinutes: 10, billableMinutes: 10,
      reservedMinutes: 420, remainingMinutes: 170, reviewMinutes: 0, visitCount: 1, clientName: "Synthetic Person",
    };
    function renderAws(permissions: string[], post: AwsApiClient["post"], get: AwsApiClient["get"]) {
      mockedUseOrganization.mockReturnValue({
        activeOrganizationId: ORG_ID,
        activeOrganization: { displayName: "Acme Care" },
        hasPermission: vi.fn((key: string) => permissions.includes(key)),
      } as never);
      const backend = {
        kind: "aws",
        listVisits: vi.fn().mockResolvedValue([]),
        getLetterhead: vi.fn().mockResolvedValue({ legal_name: "Acme Care LLC", display_name: "Acme Care" }),
        listClientLocations: vi.fn().mockResolvedValue([]),
        listCorrections: vi.fn().mockResolvedValue([]),
        listMonthlyServiceSummary: vi.fn().mockResolvedValue([summaryRow]),
        listMonthlyApprovalSummary: vi.fn().mockResolvedValue([]),
      } as unknown as ServiceVerificationBackend;
      const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      render(
        <MemoryRouter initialEntries={["/service-verification/reports?view=reconciliation"]}>
          <QueryClientProvider client={queryClient}>
            <AwsApiContext.Provider value={{ get, post }}>
              <ServiceVerificationBackendContext.Provider value={backend}>
                <ServiceVerificationReportsPage />
              </ServiceVerificationBackendContext.Provider>
            </AwsApiContext.Provider>
          </QueryClientProvider>
        </MemoryRouter>,
      );
    }
    const get = vi.fn(async () => ({ rows: [] })) as unknown as AwsApiClient["get"];
    void get;

    const chainRow = (o: Record<string, unknown> = {}) => ({
      clientId: "c1", clientCode: "TEST-C01", serviceId: "s1", serviceCode: "RSP", serviceName: "Respite", authorizationLineageId: "l1", authorizationVersion: 2, periodStart: "2026-10-01", periodEnd: "2026-12-31",
      authorizedMinutes: 600, scheduledMinutes: 60, heldReviewMinutes: 0, needsReconciliationMinutes: 35, reservedMinutes: 95, workedMinutes: 140, confirmedMinutes: 120, billableMinutes: 120,
      needsCorrectionMinutes: 0, waitingMinutes: 0, readyForReviewMinutes: 80, approvedForBillingMinutes: 40, reviewedNotBillableMinutes: 0, humanApprovedMinutes: 40,
      needsCorrectionVisits: 1, waitingVisits: 0, readyForReviewVisits: 2, approvedVisits: 1, voidedApprovals: 1, adjustmentMinutes: 0, committedMinutes: 215, remainingMinutes: 385, overLimitMinutes: 0,
      reservedOk: true, visitsOk: true, balanceOk: true, differenceMinutes: 0, ...o,
    });

    it("the full-chain report shows every stage and a passing check; Export CSV is the server's own recorded export", async () => {
      const createObjectURL = vi.fn(() => "blob:x");
      Object.defineProperty(URL, "createObjectURL", { configurable: true, value: createObjectURL });
      Object.defineProperty(URL, "revokeObjectURL", { configurable: true, value: vi.fn() });
      const post = vi.fn(async () => ({ exportId: "e9", filename: "monthly-chain-2026-10.csv", csv: "a,b", rowCount: 1, byteCount: 3 })) as unknown as AwsApiClient["post"];
      const getRows = vi.fn(async () => ({ rows: [chainRow()] })) as unknown as AwsApiClient["get"];
      renderAws(["visits.read", "billing.visits.read", "reports.export"], post, getRows);
      const section = await screen.findByTestId("monthly-chain");
      expect(await within(section).findByText("Client TEST-C01 · Respite")).toBeInTheDocument();
      expect(within(section).getByTestId("chain-checks")).toHaveTextContent("All checks pass");
      expect(within(section).getByText(/Approval is not submission or payment/)).toBeInTheDocument();
      const row = within(section).getByRole("row", { name: /TEST-C01/ });
      expect(row).toHaveTextContent("35 min"); // to reconcile
      expect(row).toHaveTextContent("1 hr 20 min"); // Billing Ready
      expect(getRows).toHaveBeenCalledWith("/v1/reports/monthly-chain", expect.objectContaining({ organizationId: ORG_ID }));
      fireEvent.click(within(section).getByRole("button", { name: "Export CSV (server-made, recorded)" }));
      await waitFor(() => expect(createObjectURL).toHaveBeenCalledTimes(1));
      expect(post).toHaveBeenCalledWith("/v1/exports", expect.objectContaining({ organizationId: ORG_ID, report: "monthly_chain" }));
      expect(await within(section).findByText(/Whether it reached this device is not recorded/)).toBeInTheDocument();
    });

    it("a row that does not add up is called out with the difference, and a non-exporter gets no export button", async () => {
      const post = vi.fn() as unknown as AwsApiClient["post"];
      const getRows = vi.fn(async () => ({ rows: [chainRow({ balanceOk: false, differenceMinutes: 15 })] })) as unknown as AwsApiClient["get"];
      renderAws(["visits.read"], post, getRows);
      const section = await screen.findByTestId("monthly-chain");
      expect(await within(section).findByTestId("chain-checks")).toHaveTextContent("1 row does not add up");
      expect(within(section).getByText("Off by 15 min")).toBeInTheDocument();
      expect(within(section).queryByRole("button", { name: "Export CSV (server-made, recorded)" })).not.toBeInTheDocument();
      expect(within(section).getByText(/Your role can read this report but not export it/)).toBeInTheDocument();
    });

    it("a person who can read but not export sees no CSV button and the page says so", async () => {
      const post = vi.fn() as unknown as AwsApiClient["post"];
      renderAws(["visits.read", "billing.visits.read"], post, get);
      await screen.findByRole("columnheader", { name: "Hours left" });
      expect(screen.queryByRole("button", { name: "CSV" })).not.toBeInTheDocument();
      expect(await screen.findByText(/Your role can read this report but not export it\./)).toBeInTheDocument();
      expect(post).not.toHaveBeenCalled();
    });

    it("an exporter's click asks the SERVER to make the file; the browser saves exactly what the server returned and does not say it was delivered", async () => {
      const saved: string[] = [];
      const createObjectURL = vi.fn((b: Blob) => { saved.push(String(b.size)); return "blob:x"; });
      Object.defineProperty(URL, "createObjectURL", { configurable: true, value: createObjectURL });
      Object.defineProperty(URL, "revokeObjectURL", { configurable: true, value: vi.fn() });
      const post = vi.fn(async () => ({ exportId: "e1", filename: "monthly-service-reconciliation-2026-10.csv", csv: "server,made", rowCount: 1, byteCount: 11 })) as unknown as AwsApiClient["post"];
      renderAws(["visits.read", "billing.visits.read", "reports.export", "clients.names.read"], post, get);
      await screen.findByRole("columnheader", { name: "Hours left" });
      fireEvent.click(screen.getAllByRole("button", { name: "CSV" })[0]!);
      await waitFor(() => expect(createObjectURL).toHaveBeenCalledTimes(1));
      expect(saved).toEqual(["11"]); // the bytes the server returned, not a file built from the page
      expect(post).toHaveBeenCalledWith("/v1/exports", expect.objectContaining({ organizationId: ORG_ID, report: "monthly_service_reconciliation", params: expect.objectContaining({ clientId: null }) }));
      const note = await screen.findByText(/The server generated monthly-service-reconciliation/);
      expect(note).toHaveTextContent("The server generated monthly-service-reconciliation-2026-10.csv (1 row) and recorded the export.");
      expect(note).toHaveTextContent("Whether the file reached this device is not recorded.");
    });

    it("when the server refuses or fails, nothing is downloaded and the reason is shown", async () => {
      const createObjectURL = vi.fn(() => "blob:x");
      Object.defineProperty(URL, "createObjectURL", { configurable: true, value: createObjectURL });
      const post = vi.fn(async () => { throw new Error("You do not have permission to export reports"); }) as unknown as AwsApiClient["post"];
      renderAws(["visits.read", "reports.export"], post, get);
      await screen.findByRole("columnheader", { name: "Hours left" });
      fireEvent.click(screen.getAllByRole("button", { name: "CSV" })[0]!);
      expect(await screen.findByRole("alert")).toHaveTextContent("You do not have permission to export reports");
      expect(createObjectURL).not.toHaveBeenCalled();
    });
  });

  it("shows each visit's scheduled shift next to the actual times, or that it has none", async () => {
    mockedUseOrganization.mockReturnValue({
      activeOrganizationId: ORG_ID,
      activeOrganization: { displayName: "Acme Care" },
      hasPermission: vi.fn(() => true),
    } as never);
    mockOrgLetterhead();
    mockedRpc.mockResolvedValue({
      data: [
        {
          ...visitRow,
          scheduled_starts_at: "2026-08-01T12:30:00.000Z",
          scheduled_ends_at: "2026-08-01T14:30:00.000Z",
        },
        {
          ...visitRow,
          id: "unlinked-1",
          visit_number: "SCS-V-20260801-9Z9Z",
          scheduled_starts_at: null,
          scheduled_ends_at: null,
        },
      ],
      error: null,
    } as never);

    renderPage();
    await openReport(/^Visit records$/);

    const table = await screen.findByRole("table", { name: "Visit details" });
    // 12:30Z-14:30Z is 5:30-7:30 AM Pacific (PDT).
    const linkedRow = within(table).getByText("SCS-V-20260801-4F7K").closest("tr")!;
    expect(linkedRow).toHaveTextContent(/Scheduled 5:30\sAM–7:30\sAM/);
    const unlinkedRow = within(table).getByText("SCS-V-20260801-9Z9Z").closest("tr")!;
    expect(unlinkedRow).toHaveTextContent("Unscheduled visit");
  });

  it("lists missed clock-outs and unconfirmed visits under Exceptions, but not visits still in their shift", async () => {
    mockedUseOrganization.mockReturnValue({
      activeOrganizationId: ORG_ID,
      activeOrganization: { displayName: "Acme Care" },
      hasPermission: vi.fn(() => true),
    } as never);
    mockOrgLetterhead();
    const ago = (minutes: number) => new Date(Date.now() - minutes * 60_000).toISOString();
    const open = { ...visitRow, status: "draft" as const, time_out: null, worked_minutes: null, billable_minutes: null, signed_at: null };
    mockedRpc.mockResolvedValue({
      data: [
        { ...open, id: "missed-1", caregiver_name: "Missed Clockout", time_in: ago(300), scheduled_starts_at: ago(300), scheduled_ends_at: ago(90) },
        { ...open, id: "working-1", caregiver_name: "Still Working", time_in: ago(30), scheduled_starts_at: ago(30), scheduled_ends_at: ago(-120) },
        { ...visitRow, id: "unconfirmed-1", caregiver_name: "Never Confirmed", status: "awaiting_signature", time_in: ago(300), time_out: ago(120), signed_at: null },
      ],
      error: null,
    } as never);

    renderPage();
    await openReport(/^Action needed$/);

    const card = (await screen.findByText("Incomplete visits (2)")).closest("div")!;
    const items = within(card).getAllByRole("listitem");
    // Most overdue first: signed out 2h ago, then 1h 30m past scheduled end.
    expect(items[0]).toHaveTextContent("Never Confirmed");
    expect(items[0]).toHaveTextContent("Not confirmed");
    expect(items[0]).toHaveTextContent("Signed out 2h 0m ago");
    expect(items[1]).toHaveTextContent("Missed Clockout");
    expect(items[1]).toHaveTextContent("Missing Time Out");
    expect(items[1]).toHaveTextContent("1h 30m past scheduled end");
    expect(card).not.toHaveTextContent("Still Working");
    expect(screen.queryByText(/No visits currently need manager attention/)).not.toBeInTheDocument();
  });

  it("lets a visit manager close a missed clock-out with an explicit Pacific date, AM/PM and duration", async () => {
    mockedUseOrganization.mockReturnValue({
      activeOrganizationId: ORG_ID,
      activeOrganization: { displayName: "Acme Care" },
      hasPermission: vi.fn(() => true),
    } as never);
    mockOrgLetterhead();
    const base = new Date();
    base.setSeconds(0, 0);
    const ago = (minutes: number) => new Date(base.getTime() - minutes * 60_000).toISOString();
    const missed = {
      ...visitRow, id: "missed-1", caregiver_name: "Missed Clockout", status: "draft" as const, time_out: null,
      worked_minutes: null, billable_minutes: null, signed_at: null,
      time_in: ago(300), scheduled_starts_at: ago(300), scheduled_ends_at: ago(90),
    };
    mockedRpc.mockImplementation((fn: string) =>
      Promise.resolve(fn === "list_service_visits" ? { data: [missed], error: null } : { data: [], error: null }) as never,
    );
    const enter = (iso: string) => {
      const wall = toPacificWallTime(iso);
      fireEvent.change(screen.getByLabelText("Time Out date"), { target: { value: wall.date } });
      fireEvent.change(screen.getByLabelText("Time Out hour"), { target: { value: String(wall.hour) } });
      fireEvent.change(screen.getByLabelText("Time Out minute"), { target: { value: String(wall.minute) } });
      fireEvent.click(screen.getByRole("radio", { name: wall.meridiem! }));
    };

    renderPage();
    await openReport(/^Action needed$/);
    fireEvent.click(await screen.findByRole("button", { name: "Close visit" }));

    // Only the date is pre-filled (Time In's Pacific date); the time must be entered.
    expect(screen.getByLabelText("Time Out date")).toHaveValue(toPacificWallTime(missed.time_in).date);
    expect(screen.getByLabelText("Time Out hour")).toHaveValue("");
    expect(screen.getByRole("radio", { name: "AM" })).toHaveAttribute("aria-checked", "false");
    expect(screen.getByRole("radio", { name: "PM" })).toHaveAttribute("aria-checked", "false");
    expect(screen.getByText(/^Scheduled end:/)).toBeInTheDocument();

    fireEvent.click(screen.getByRole("button", { name: "Save Time Out" }));
    expect(await screen.findByRole("alert")).toHaveTextContent("A reason is required to close a missed visit.");

    fireEvent.change(screen.getByLabelText("Reason"), { target: { value: "Caregiver confirmed by phone" } });
    fireEvent.click(screen.getByRole("button", { name: "Save Time Out" }));
    expect(await screen.findByRole("alert")).toHaveTextContent("Choose the hour, minute, and AM or PM.");

    // Before Time In (e.g. the wrong AM/PM): named, with both times.
    enter(ago(360));
    fireEvent.click(screen.getByRole("button", { name: "Save Time Out" }));
    expect(await screen.findByRole("alert")).toHaveTextContent(/must be after Time In \(.+\)\. Check the date and AM\/PM\./);

    // In the future.
    enter(new Date(base.getTime() + 120 * 60_000).toISOString());
    fireEvent.click(screen.getByRole("button", { name: "Save Time Out" }));
    expect(await screen.findByRole("alert")).toHaveTextContent(/is in the future/);
    expect(mockedRpc).not.toHaveBeenCalledWith("close_missed_service_visit", expect.anything());

    // Valid: editing clears the stale error; the summary spells out Time In,
    // Time Out and the worked duration.
    enter(ago(60));
    expect(screen.queryByRole("alert")).not.toBeInTheDocument();
    const summary = screen.getByLabelText("Time Out summary");
    expect(summary).toHaveTextContent(`${formatVisitDate(ago(60))}, ${formatClockTime(ago(60))}`);
    expect(summary).toHaveTextContent("Duration4 hr");
    fireEvent.click(screen.getByRole("button", { name: "Save Time Out" }));
    await waitFor(() =>
      expect(mockedRpc).toHaveBeenCalledWith("close_missed_service_visit", {
        target_visit_id: "missed-1",
        actual_time_out: ago(60),
        reason: "Caregiver confirmed by phone",
      }),
    );
  });

  // 0085 (D10): a visit that never happened is kept apart from actual work with a missing clock-out.
  describe("No service delivered (visit that never happened)", () => {
    const base = new Date(); base.setSeconds(0, 0);
    const ago = (minutes: number) => new Date(base.getTime() - minutes * 60_000).toISOString();
    const missed = () => ({
      ...visitRow, id: "missed-2", caregiver_name: "Started In Error", status: "draft" as const, time_out: null, worked_minutes: null, billable_minutes: null, signed_at: null,
      time_in: ago(300), scheduled_starts_at: ago(300), scheduled_ends_at: ago(90),
    });
    function renderAws(markNoService: ReturnType<typeof vi.fn> | undefined) {
      mockedUseOrganization.mockReturnValue({ activeOrganizationId: ORG_ID, activeOrganization: { displayName: "Acme Care" }, hasPermission: vi.fn(() => true) } as never);
      const backend = {
        kind: "aws",
        listVisits: vi.fn().mockResolvedValue([missed()]),
        getLetterhead: vi.fn().mockResolvedValue({ legal_name: "Acme Care LLC", display_name: "Acme Care" }),
        listClientLocations: vi.fn().mockResolvedValue([]),
        listCorrections: vi.fn().mockResolvedValue([]),
        closeMissedVisit: vi.fn().mockResolvedValue(undefined),
        ...(markNoService ? { markNoServiceDelivered: markNoService } : {}),
      } as unknown as ServiceVerificationBackend;
      const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      render(
        <MemoryRouter initialEntries={["/service-verification/reports?view=exceptions"]}>
          <QueryClientProvider client={queryClient}>
            <ServiceVerificationBackendContext.Provider value={backend}><ServiceVerificationReportsPage /></ServiceVerificationBackendContext.Provider>
          </QueryClientProvider>
        </MemoryRouter>,
      );
      return backend;
    }

    it("offers it beside Close visit, needs a reason, asks for no Time Out, and sends the visit and reason once", async () => {
      const mark = vi.fn().mockResolvedValue(undefined);
      const backend = renderAws(mark);
      fireEvent.click(await screen.findByRole("button", { name: "No service delivered" }));
      expect(screen.getByText(/Use this only when the visit never happened/)).toBeInTheDocument();
      expect(screen.getByText(/did work and only forgot to clock out, cancel and use Close visit/)).toBeInTheDocument();
      expect(screen.queryByLabelText("Time Out date")).not.toBeInTheDocument();
      fireEvent.click(screen.getByRole("button", { name: "Record: no service delivered" }));
      expect(await screen.findByRole("alert")).toHaveTextContent("A reason is required to record that no service was delivered.");
      expect(mark).not.toHaveBeenCalled();
      fireEvent.change(screen.getByLabelText("Reason"), { target: { value: "Started by mistake; caregiver never went (synthetic)" } });
      fireEvent.click(screen.getByRole("button", { name: "Record: no service delivered" }));
      await waitFor(() => expect(mark).toHaveBeenCalledTimes(1));
      expect(mark).toHaveBeenCalledWith(expect.objectContaining({ visitId: "missed-2", reason: "Started by mistake; caregiver never went (synthetic)" }));
      expect((backend as unknown as { closeMissedVisit: ReturnType<typeof vi.fn> }).closeMissedVisit).not.toHaveBeenCalled();
    });

    it("Close visit still enters a Time Out and keeps the worked time (actual work, missing clock-out); the two actions are different forms", async () => {
      renderAws(vi.fn());
      fireEvent.click(await screen.findByRole("button", { name: "Close visit" }));
      expect(screen.getByLabelText("Time Out date")).toBeInTheDocument();
      expect(screen.getByRole("button", { name: "Save Time Out" })).toBeInTheDocument();
      expect(screen.queryByText(/Use this only when the visit never happened/)).not.toBeInTheDocument();
    });

    it("shows the server's refusal and does not hide the form; a backend without the action (the older one) shows no such button", async () => {
      const mark = vi.fn().mockRejectedValue(new Error("A signed visit cannot be voided - use a correction instead"));
      renderAws(mark);
      fireEvent.click(await screen.findByRole("button", { name: "No service delivered" }));
      fireEvent.change(screen.getByLabelText("Reason"), { target: { value: "Never happened (synthetic)" } });
      fireEvent.click(screen.getByRole("button", { name: "Record: no service delivered" }));
      expect(await screen.findByRole("alert")).toHaveTextContent(/cannot be voided/);
      expect(screen.getByLabelText("Reason")).toHaveValue("Never happened (synthetic)");
    });

    it("an older backend without markNoServiceDelivered shows only Close visit", async () => {
      renderAws(undefined);
      expect(await screen.findByRole("button", { name: "Close visit" })).toBeInTheDocument();
      expect(screen.queryByRole("button", { name: "No service delivered" })).not.toBeInTheDocument();
    });
  });

  it("shows the server's message when it refuses a Time Out (e.g. an overlap)", async () => {
    mockedUseOrganization.mockReturnValue({
      activeOrganizationId: ORG_ID,
      activeOrganization: { displayName: "Acme Care" },
      hasPermission: vi.fn(() => true),
    } as never);
    mockOrgLetterhead();
    const base = new Date();
    base.setSeconds(0, 0);
    const ago = (minutes: number) => new Date(base.getTime() - minutes * 60_000).toISOString();
    const missed = {
      ...visitRow, id: "missed-1", status: "draft" as const, time_out: null, worked_minutes: null,
      billable_minutes: null, signed_at: null, time_in: ago(300), scheduled_starts_at: ago(300), scheduled_ends_at: ago(90),
    };
    mockedRpc.mockImplementation((fn: string) =>
      Promise.resolve(
        fn === "list_service_visits"
          ? { data: [missed], error: null }
          : fn === "close_missed_service_visit"
            ? { data: null, error: { message: "The Time Out overlaps another visit for this caregiver" } }
            : { data: [], error: null },
      ) as never,
    );

    renderPage();
    await openReport(/^Action needed$/);
    fireEvent.click(await screen.findByRole("button", { name: "Close visit" }));
    const wall = toPacificWallTime(ago(60));
    fireEvent.change(screen.getByLabelText("Time Out date"), { target: { value: wall.date } });
    fireEvent.change(screen.getByLabelText("Time Out hour"), { target: { value: String(wall.hour) } });
    fireEvent.change(screen.getByLabelText("Time Out minute"), { target: { value: String(wall.minute) } });
    fireEvent.click(screen.getByRole("radio", { name: wall.meridiem! }));
    fireEvent.change(screen.getByLabelText("Reason"), { target: { value: "Phone check" } });
    fireEvent.click(screen.getByRole("button", { name: "Save Time Out" }));
    expect(await screen.findByRole("alert")).toHaveTextContent("The Time Out overlaps another visit for this caregiver");
  });

  it("corrects a signed visit in Pacific time with explicit AM/PM, specific errors and the exact instants saved", async () => {
    mockedUseOrganization.mockReturnValue({
      activeOrganizationId: ORG_ID,
      activeOrganization: { displayName: "Acme Care" },
      hasPermission: vi.fn(() => true),
    } as never);
    mockOrgLetterhead();
    mockedRpc.mockImplementation((fn: string) =>
      Promise.resolve(fn === "list_service_visits" ? { data: [visitRow], error: null } : { data: [], error: null }) as never,
    );

    renderPage();
    await openReport(/^Visit records$/);
    fireEvent.click(await screen.findByRole("button", { name: "Correct" }));

    // Pre-filled from the original record in Pacific time (13:00Z = 6:00 AM PDT),
    // whatever the device timezone.
    expect(screen.getByLabelText("Corrected Time In date")).toHaveValue("2026-08-01");
    expect(screen.getByLabelText("Corrected Time In hour")).toHaveValue("6");
    expect(screen.getByLabelText("Corrected Time Out hour")).toHaveValue("7");
    const inGroup = screen.getByRole("radiogroup", { name: "Corrected Time In AM or PM" });
    expect(within(inGroup).getByRole("radio", { name: "AM" })).toHaveAttribute("aria-checked", "true");
    const summary = screen.getByLabelText("Correction summary");
    expect(summary).toHaveTextContent("08/01/2026, 6:00 AM → 08/01/2026, 7:00 AM (1 hr)");

    fireEvent.click(screen.getByRole("button", { name: "Save correction" }));
    expect(await screen.findByRole("alert")).toHaveTextContent("A reason is required to correct a visit.");
    fireEvent.change(screen.getByLabelText("Reason (required)"), { target: { value: "Caregiver left later (synthetic)" } });

    // Time Out before Time In: named, with both times.
    fireEvent.change(screen.getByLabelText("Corrected Time Out hour"), { target: { value: "5" } });
    expect(screen.queryByRole("alert")).not.toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Save correction" }));
    expect(await screen.findByRole("alert")).toHaveTextContent(
      "Time Out (08/01/2026, 5:00 AM) must be after Time In (08/01/2026, 6:00 AM). Check the date and AM/PM.",
    );
    expect(mockedRpc).not.toHaveBeenCalledWith("correct_service_visit", expect.anything());

    fireEvent.change(screen.getByLabelText("Corrected Time Out hour"), { target: { value: "7" } });
    fireEvent.change(screen.getByLabelText("Corrected Time Out minute"), { target: { value: "30" } });
    expect(summary).toHaveTextContent("→ 08/01/2026, 7:30 AM (1 hr 30 min)");
    fireEvent.click(screen.getByRole("button", { name: "Save correction" }));
    await waitFor(() =>
      expect(mockedRpc).toHaveBeenCalledWith("correct_service_visit", {
        target_visit_id: visitRow.id,
        new_time_in: "2026-08-01T13:00:00.000Z",
        new_time_out: "2026-08-01T14:30:00.000Z",
        reason: "Caregiver left later (synthetic)",
      }),
    );
  });

  it("sends an unchanged Time In exactly as stored, seconds included", async () => {
    mockedUseOrganization.mockReturnValue({
      activeOrganizationId: ORG_ID,
      activeOrganization: { displayName: "Acme Care" },
      hasPermission: vi.fn(() => true),
    } as never);
    mockOrgLetterhead();
    const withSeconds = { ...visitRow, time_in: "2026-08-01T13:00:37.123456+00:00", time_out: "2026-08-01T14:00:12.5+00:00" };
    mockedRpc.mockImplementation((fn: string) =>
      Promise.resolve(fn === "list_service_visits" ? { data: [withSeconds], error: null } : { data: [], error: null }) as never,
    );
    renderPage();
    await openReport(/^Visit records$/);
    fireEvent.click(await screen.findByRole("button", { name: "Correct" }));
    fireEvent.change(screen.getByLabelText("Reason (required)"), { target: { value: "Left later (synthetic)" } });
    fireEvent.change(screen.getByLabelText("Corrected Time Out minute"), { target: { value: "20" } });
    fireEvent.click(screen.getByRole("button", { name: "Save correction" }));
    await waitFor(() =>
      expect(mockedRpc).toHaveBeenCalledWith("correct_service_visit", {
        target_visit_id: visitRow.id,
        new_time_in: "2026-08-01T13:00:37.123456+00:00",
        new_time_out: "2026-08-01T14:20:00.000Z",
        reason: "Left later (synthetic)",
      }),
    );
  });

  it("refuses an incomplete corrected time with a message naming which time", async () => {
    mockedUseOrganization.mockReturnValue({
      activeOrganizationId: ORG_ID,
      activeOrganization: { displayName: "Acme Care" },
      hasPermission: vi.fn(() => true),
    } as never);
    mockOrgLetterhead();
    mockedRpc.mockImplementation((fn: string) =>
      Promise.resolve(fn === "list_service_visits" ? { data: [visitRow], error: null } : { data: [], error: null }) as never,
    );
    renderPage();
    await openReport(/^Visit records$/);
    fireEvent.click(await screen.findByRole("button", { name: "Correct" }));
    fireEvent.change(screen.getByLabelText("Reason (required)"), { target: { value: "x" } });
    fireEvent.change(screen.getByLabelText("Corrected Time In minute"), { target: { value: "" } });
    fireEvent.click(screen.getByRole("button", { name: "Save correction" }));
    expect(await screen.findByRole("alert")).toHaveTextContent("Time In: Choose the hour, minute, and AM or PM.");
  });

  it("does not offer the close-out without visits.manage", async () => {
    mockedUseOrganization.mockReturnValue({
      activeOrganizationId: ORG_ID,
      activeOrganization: { displayName: "Acme Care" },
      hasPermission: vi.fn((key: string) => key !== "visits.manage"),
    } as never);
    mockOrgLetterhead();
    const ago = (minutes: number) => new Date(Date.now() - minutes * 60_000).toISOString();
    mockedRpc.mockResolvedValue({
      data: [{
        ...visitRow, id: "missed-1", status: "draft" as const, time_out: null, worked_minutes: null,
        billable_minutes: null, signed_at: null, time_in: ago(300), scheduled_starts_at: ago(300), scheduled_ends_at: ago(90),
      }],
      error: null,
    } as never);

    renderPage();
    await openReport(/^Action needed$/);
    expect(await screen.findByText("Missing Time Out")).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Close visit" })).not.toBeInTheDocument();
  });

  it("marks visits whose Time Out a manager entered", async () => {
    mockedUseOrganization.mockReturnValue({
      activeOrganizationId: ORG_ID,
      activeOrganization: { displayName: "Acme Care" },
      hasPermission: vi.fn(() => true),
    } as never);
    mockOrgLetterhead();
    mockedRpc.mockResolvedValue({ data: [{ ...visitRow, time_out_entered_by_manager: true }], error: null } as never);

    renderPage();
    await openReport(/^Visit records$/);
    const table = await screen.findByRole("table", { name: "Visit details" });
    expect(within(table).getByText("Time Out entered by manager")).toBeInTheDocument();
  });

  it("does not offer the AWS-only reports on the Supabase back end, even from a link", async () => {
    allowEverything();
    const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });
    render(
      <MemoryRouter initialEntries={["/service-verification/reports?view=corrections"]}>
        <QueryClientProvider client={queryClient}>
          <ServiceVerificationReportsPage />
        </QueryClientProvider>
      </MemoryRouter>,
    );
    await screen.findByRole("option", { name: "Visits overview" });
    expect(screen.queryByRole("option", { name: "Monthly hours & billing" })).not.toBeInTheDocument();
    expect(screen.queryByRole("option", { name: "Correction history" })).not.toBeInTheDocument();
    // A saved link to a view this back end cannot supply opens the default view, not an empty report.
    expect(screen.getByLabelText("Report")).toHaveValue("overview");
    expect(screen.queryByText("No corrections match these filters.")).not.toBeInTheDocument();
  });

  it("offers Monthly hours & billing and Correction history when the back end supplies them", async () => {
    allowEverything();
    const backend = {
      kind: "aws",
      listVisits: vi.fn().mockResolvedValue([]),
      getLetterhead: vi.fn().mockResolvedValue({ legal_name: "Acme Care LLC", display_name: "Acme Care" }),
      listClientLocations: vi.fn().mockResolvedValue([]),
      listCorrections: vi.fn().mockResolvedValue([]),
      listMonthlyServiceSummary: vi.fn().mockResolvedValue([]),
      listCorrectionHistoryReport: vi.fn().mockResolvedValue([]),
    } as unknown as ServiceVerificationBackend;
    const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });
    render(
      <MemoryRouter initialEntries={["/service-verification/reports?view=corrections"]}>
        <QueryClientProvider client={queryClient}>
          <ServiceVerificationBackendContext.Provider value={backend}>
            <ServiceVerificationReportsPage />
          </ServiceVerificationBackendContext.Provider>
        </QueryClientProvider>
      </MemoryRouter>,
    );
    expect(await screen.findByRole("option", { name: "Monthly hours & billing" })).toBeInTheDocument();
    expect(screen.getByRole("option", { name: "Correction history" })).toBeInTheDocument();
    expect(screen.getByLabelText("Report")).toHaveValue("corrections");
  });

  it("shows scheduled (reserved) time and what is left to schedule in the monthly reconciliation", async () => {
    mockedUseOrganization.mockReturnValue({
      activeOrganizationId: ORG_ID,
      activeOrganization: { displayName: "Acme Care" },
      hasPermission: vi.fn(() => true),
    } as never);
    const backend = {
      listVisits: vi.fn().mockResolvedValue([]),
      getLetterhead: vi.fn().mockResolvedValue({ legal_name: "Acme Care LLC", display_name: "Acme Care" }),
      listClientLocations: vi.fn().mockResolvedValue([]),
      listCorrections: vi.fn().mockResolvedValue([]),
      listMonthlyServiceSummary: vi.fn().mockResolvedValue([
        {
          clientId: "c1", clientCode: "TEST-C01", serviceId: "s1", serviceCode: "RSP", serviceName: "Respite",
          authorizationLineageId: "l1", authorizationPeriodStart: "2026-10-01", authorizationPeriodEnd: "2026-12-31",
          authorizedMinutes: 600, workedMinutes: 10, verifiedMinutes: 10, billableMinutes: 10,
          reservedMinutes: 420, remainingMinutes: 170, reviewMinutes: 0, visitCount: 1, clientName: "Synthetic Person",
        },
      ]),
      listMonthlyApprovalSummary: vi.fn().mockResolvedValue([
        { authorizationLineageId: "l1", approvedMinutes: 5, approvedVisitCount: 1, roundingAdjustmentMinutes: 0 },
      ]),
    } as unknown as ServiceVerificationBackend;
    const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });
    render(
      <MemoryRouter>
        <QueryClientProvider client={queryClient}>
          <ServiceVerificationBackendContext.Provider value={backend}>
            <ServiceVerificationReportsPage />
          </ServiceVerificationBackendContext.Provider>
        </QueryClientProvider>
      </MemoryRouter>,
    );
    fireEvent.change(screen.getByLabelText("Report"), { target: { value: "reconciliation" } });

    const header = await screen.findByRole("columnheader", { name: "Hours left" });
    const table = header.closest("table")!;
    const headers = within(table).getAllByRole("columnheader").map((th) => th.textContent);
    const row = within(table).getAllByRole("row")[1]!;
    const cells = within(row).getAllByRole("cell").map((td) => td.textContent);
    expect(cells[headers.indexOf("Reserved")]).toBe("7 hr");
    expect(cells[headers.indexOf("Hours left")]).toBe("2 hr 50 min");
    // Client name first with the code; billable (eligible) and human-approved stay separate.
    expect(cells[headers.indexOf("Client")]).toBe("Synthetic Person");
    expect(cells[headers.indexOf("Billable (eligible)")]).toBe("10 min");
    await waitFor(() => expect(within(within(table).getAllByRole("row")[1]!).getAllByRole("cell")[headers.indexOf("Approved")]).toHaveTextContent("5 min"));
    expect(headers).not.toContain("Submitted");
    expect(screen.getByText(/Approval is not submission/)).toBeInTheDocument();
    expect(within(row).getByText("10/01/2026–12/31/2026")).toBeInTheDocument();
  });

  it("lists visits and computes worked/billable subtotals, excluding corrected records", async () => {
    mockedUseOrganization.mockReturnValue({
      activeOrganizationId: ORG_ID,
      activeOrganization: { displayName: "Acme Care" },
      hasPermission: vi.fn(() => true),
    } as never);
    mockOrgLetterhead();
    mockedRpc.mockResolvedValue({
      data: [
        visitRow,
        {
          ...visitRow,
          id: "corrected-1",
          status: "corrected",
          is_corrected: true,
          worked_minutes: 30,
          billable_minutes: 30,
        },
      ],
      error: null,
    } as never);

    renderPage();

    await openReport(/^Visit records$/);

    expect(await screen.findByText("Visits (1)")).toBeInTheDocument();
    // "Jamie Smith" also appears in the client filter <option> and the
    // per-client subtotal card, so this only checks it appears in the
    // table row, not that it appears exactly once anywhere on the page.
    const table = screen.getByRole("table", { name: "Visit details" });
    expect(table).toHaveTextContent("Jamie Smith");
    // Superseded correction-chain rows are hidden by default; totals count
    // only the current signed/reviewable version.
    expect(screen.getByText("Worked: 1 hr")).toBeInTheDocument();
    expect(screen.getByText("Billable: 1 hr")).toBeInTheDocument();
    expect(screen.queryByText("Replaced by a correction")).not.toBeInTheDocument();
    fireEvent.click(screen.getByLabelText("Replaced"));
    expect(await screen.findByText("Replaced by a correction")).toBeInTheDocument();
  });

  it("shows manager filters, charts, and a caregiver-hours sheet", async () => {
    mockedUseOrganization.mockReturnValue({
      activeOrganizationId: ORG_ID,
      activeOrganization: { displayName: "Acme Care" },
      hasPermission: vi.fn(() => true),
    } as never);
    mockOrgLetterhead();
    mockedRpc.mockResolvedValue({ data: [visitRow], error: null } as never);

    renderPage();

    expect(await screen.findByRole("heading", { name: "Reports" })).toBeInTheDocument();
    expect(
      await screen.findByRole("option", { name: "Anaheim, CA" }),
    ).toBeInTheDocument();
    expect(screen.getByLabelText("Chart type")).toHaveValue("bar");
    expect(screen.getByLabelText("Group chart by")).toHaveValue("caregiver");
    expect(
      screen.queryByRole("table", { name: "Caregiver hours summary" }),
    ).not.toBeInTheDocument();

    await openReport(/Caregiver hours/);
    const caregiverSheet = screen.getByRole("table", {
      name: "Caregiver hours summary",
    });
    expect(caregiverSheet).toHaveTextContent("Jordan Rivera");
    expect(caregiverSheet).toHaveTextContent("1 hr");
  });

  it("copies one common staff link and explains assignment protection", async () => {
    mockedUseOrganization.mockReturnValue({
      activeOrganizationId: ORG_ID,
      activeOrganization: { displayName: "Acme Care" },
      hasPermission: vi.fn(() => true),
    } as never);
    mockOrgLetterhead();
    mockedRpc.mockResolvedValue({ data: [visitRow], error: null } as never);
    const writeText = vi.fn().mockResolvedValue(undefined);
    Object.defineProperty(navigator, "clipboard", {
      configurable: true,
      value: { writeText },
    });

    renderPage();

    await openReport(/Staff access/);

    fireEvent.click(
      await screen.findByRole("button", { name: "Copy staff sign-in link" }),
    );
    await waitFor(() =>
      expect(writeText).toHaveBeenCalledWith(
        `${window.location.origin}/service-verification`,
      ),
    );
    expect(screen.getByText("Staff link copied")).toBeInTheDocument();
    expect(
      screen.getByText(/can only see clients and services assigned to them/i),
    ).toBeInTheDocument();
  });

  it("maps each service's daily worked and billable hours into the monthly client calendar", async () => {
    mockedUseOrganization.mockReturnValue({
      activeOrganizationId: ORG_ID,
      activeOrganization: { displayName: "Acme Care" },
      hasPermission: vi.fn(() => true),
    } as never);
    mockOrgLetterhead();
    mockedRpc.mockResolvedValue({
      data: [
        visitRow,
        {
          ...visitRow,
          id: "needs-review",
          caregiver_user_id: "review-caregiver",
          caregiver_name: "Sam Caregiver",
          worked_minutes: 45,
          verified_minutes: 0,
          billable_minutes: 0,
          status: "administrator_review",
        },
        {
          ...visitRow,
          id: "superseded",
          caregiver_user_id: "old-caregiver",
          caregiver_name: "Old Record",
          status: "corrected",
          is_corrected: true,
        },
      ],
      error: null,
    } as never);

    renderPage();

    // Wait until the visit query has populated the client option before
    // selecting it. Changing a native <select> to a value whose option has
    // not rendered yet resolves back to the empty "All clients" value.
    await screen.findByRole("option", { name: "Jamie Smith" });
    fireEvent.change(screen.getByLabelText("Client"), {
      target: { value: visitRow.client_id },
    });
    await openReport(/Client monthly calendar/);
    fireEvent.change(screen.getByLabelText("Calendar month"), {
      target: { value: "2026-08" },
    });

    const calendar = await screen.findByRole("grid", {
      name: /Service hours for Jamie Smith in 2026-08/,
    });
    expect(await within(calendar).findByText("Personal Care")).toBeInTheDocument();
    expect(within(calendar).getByText("1 hr 45 min")).toBeInTheDocument();
    expect(within(calendar).getByText("Billable 1 hr")).toBeInTheDocument();
    expect(within(calendar).queryByText("Jordan Rivera")).not.toBeInTheDocument();
    expect(within(calendar).queryByText("Old Record")).not.toBeInTheDocument();
    // The calendar has its own whole-month query for this client: the
    // caregiver, service, status and date filters never make it a partial total.
    expect(mockedRpc).toHaveBeenCalledWith("list_service_visits", {
      target_organization_id: ORG_ID,
      filter_client_id: visitRow.client_id,
      filter_caregiver_user_id: null,
      filter_service_id: null,
      filter_date_from: "2026-08-01",
      filter_date_to: "2026-08-31",
      filter_status: null,
    });
    expect(screen.getByRole("button", { name: /Print calendar/ })).toBeEnabled();
  });

  it("shows exception visits flagged for review, correction, or over-authorization, but not a plain signed visit", async () => {
    mockedUseOrganization.mockReturnValue({
      activeOrganizationId: ORG_ID,
      activeOrganization: { displayName: "Acme Care" },
      hasPermission: vi.fn(() => true),
    } as never);
    mockOrgLetterhead();
    mockedRpc.mockResolvedValue({
      data: [
        visitRow,
        { ...visitRow, id: "needs-review", status: "administrator_review" },
        {
          ...visitRow,
          id: "over-authorized",
          authorization_status: "exceeds_authorization",
        },
      ],
      error: null,
    } as never);

    renderPage();

    await openReport(/^Action needed$/);

    await waitFor(() =>
      expect(screen.getByText("Exception visits")).toBeInTheDocument(),
    );
    const exceptionCard = screen.getByText("Exception visits").closest("div")!;
    expect(within(exceptionCard).getByText("In review")).toBeInTheDocument();
    expect(
      within(exceptionCard).getByText("Exceeds authorization"),
    ).toBeInTheDocument();
    // Only 2 rows in the card: the plain signed/within-authorization
    // visitRow itself never appears here.
    expect(within(exceptionCard).getAllByRole("listitem")).toHaveLength(2);
  });

  it("uses actual signed visit time and does not load fixed schedules", async () => {
    mockedUseOrganization.mockReturnValue({
      activeOrganizationId: ORG_ID,
      activeOrganization: { displayName: "Acme Care" },
      hasPermission: vi.fn(() => true),
    } as never);
    mockOrgLetterhead();
    mockedRpc.mockImplementation((fn: string) => {
      if (fn === "list_service_visits") {
        return Promise.resolve({ data: [visitRow], error: null }) as never;
      }
      if (fn === "list_shifts") {
        return Promise.resolve({
          data: [
            {
              client_id: visitRow.client_id,
              client_name: "Jamie Smith",
              caregiver_user_id: visitRow.caregiver_user_id,
              caregiver_name: "Jordan Rivera",
              starts_at: "2026-08-01T13:00:00.000Z",
              ends_at: "2026-08-01T14:30:00.000Z",
              status: "completed",
            },
            {
              client_id: "unsigned-client",
              client_name: "Alex Doe",
              caregiver_user_id: "unsigned-caregiver",
              caregiver_name: "Sam Caregiver",
              starts_at: "2026-08-02T13:00:00.000Z",
              ends_at: "2026-08-02T14:00:00.000Z",
              status: "scheduled",
            },
          ],
          error: null,
        }) as never;
      }
      return Promise.resolve({ data: [], error: null }) as never;
    });

    renderPage();

    await waitFor(() =>
      expect(screen.getByText(/actual signed visit time/i)).toBeInTheDocument(),
    );
    expect(
      screen.queryByText("Scheduled vs delivered hours"),
    ).not.toBeInTheDocument();
    expect(mockedRpc).not.toHaveBeenCalledWith(
      "list_shifts",
      expect.anything(),
    );
  });

  it("does not create scheduled-hour totals when there are no signed visits", async () => {
    mockedUseOrganization.mockReturnValue({
      activeOrganizationId: ORG_ID,
      activeOrganization: { displayName: "Acme Care" },
      hasPermission: vi.fn(() => true),
    } as never);
    mockOrgLetterhead();
    mockedRpc.mockImplementation((fn: string) => {
      if (fn === "list_service_visits") {
        return Promise.resolve({ data: [], error: null }) as never;
      }
      if (fn === "list_shifts") {
        return Promise.resolve({
          data: [
            {
              client_id: "called-out-client",
              client_name: "Robin Lee",
              caregiver_user_id: "called-out-caregiver",
              caregiver_name: "Casey Nguyen",
              starts_at: "2026-08-03T13:00:00.000Z",
              ends_at: "2026-08-03T15:00:00.000Z",
              status: "scheduled",
              needs_coverage: true,
            },
          ],
          error: null,
        }) as never;
      }
      return Promise.resolve({ data: [], error: null }) as never;
    });

    renderPage();

    await waitFor(() =>
      expect(screen.getByText(/actual signed visit time/i)).toBeInTheDocument(),
    );
    expect(screen.queryByText(/scheduled ·/i)).not.toBeInTheDocument();
    expect(mockedRpc).not.toHaveBeenCalledWith(
      "list_shifts",
      expect.anything(),
    );
  });

  it("passes filter selections through to list_service_visits", async () => {
    mockedUseOrganization.mockReturnValue({
      activeOrganizationId: ORG_ID,
      activeOrganization: { displayName: "Acme Care" },
      hasPermission: vi.fn(() => true),
    } as never);
    mockOrgLetterhead();
    mockedRpc.mockResolvedValue({ data: [visitRow], error: null } as never);

    renderPage();
    await waitFor(() =>
      expect(screen.getByLabelText("Client")).toBeInTheDocument(),
    );

    // Custom range: the date-range dropdown reveals From and To.
    fireEvent.change(screen.getByLabelText("Date range"), { target: { value: "custom" } });
    fireEvent.change(screen.getByLabelText("From"), {
      target: { value: "2026-08-01" },
    });
    fireEvent.change(screen.getByLabelText("To"), {
      target: { value: "2026-08-31" },
    });

    await waitFor(() =>
      expect(mockedRpc).toHaveBeenCalledWith(
        "list_service_visits",
        expect.objectContaining({
          target_organization_id: ORG_ID,
          filter_date_from: "2026-08-01",
          filter_date_to: "2026-08-31",
        }),
      ),
    );
  });

  it("opens a named caregiver folder and preserves it in the report link", async () => {
    mockedUseOrganization.mockReturnValue({
      activeOrganizationId: ORG_ID,
      activeOrganization: { displayName: "Acme Care" },
      hasPermission: vi.fn(() => true),
    } as never);
    mockOrgLetterhead();
    mockedRpc.mockResolvedValue({ data: [visitRow], error: null } as never);

    renderPage();
    await openReport(/Caregiver hours/);
    fireEvent.click(
      await screen.findByRole("button", { name: /Caregiver Jordan Rivera/ }),
    );

    await waitFor(() =>
      expect(window.location.search).toContain(
        `caregiver=${visitRow.caregiver_user_id}`,
      ),
    );
    expect(
      await screen.findByRole("button", { name: "All caregivers" }),
    ).toBeInTheDocument();
  });

  it("shows the visit number with separate authorized, used MTD, and remaining values", async () => {
    mockedUseOrganization.mockReturnValue({
      activeOrganizationId: ORG_ID,
      activeOrganization: { displayName: "Acme Care" },
      hasPermission: vi.fn(() => true),
    } as never);
    mockOrgLetterhead();
    mockedRpc.mockResolvedValue({ data: [visitRow], error: null } as never);

    renderPage();

    await openReport(/^Visit records$/);

    expect(await screen.findByText("SCS-V-20260801-4F7K")).toBeInTheDocument();
    const visitTable = screen.getByRole("table", { name: "Visit details" });
    // Shown under the row's Hours left control (and, for a printout, written out in full).
    const row = within(visitTable).getByText("SCS-V-20260801-4F7K").closest("tr")!;
    expect(row).toHaveTextContent("Authorized: 40 hr");
    expect(row).toHaveTextContent("Billable this month: 11 hr");
    expect(row).toHaveTextContent("Hours left: 29 hr");
  });

  it("submits a correction for a signed visit", async () => {
    mockedUseOrganization.mockReturnValue({
      activeOrganizationId: ORG_ID,
      activeOrganization: { displayName: "Acme Care" },
      hasPermission: vi.fn(() => true),
    } as never);
    mockOrgLetterhead();
    mockedRpc.mockImplementation((fn: string) => {
      if (fn === "list_service_visits")
        return Promise.resolve({ data: [visitRow], error: null }) as never;
      if (fn === "correct_service_visit")
        return Promise.resolve({ data: "corrected-id", error: null }) as never;
      return Promise.resolve({ data: [], error: null }) as never;
    });

    renderPage();
    await openReport(/^Visit records$/);
    await screen.findByText("SCS-V-20260801-4F7K");

    fireEvent.click(screen.getByRole("button", { name: "Correct" }));
    fireEvent.change(screen.getByLabelText("Reason (required)"), {
      target: { value: "Forgot to clock out on time" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Save correction" }));

    await waitFor(() =>
      expect(mockedRpc).toHaveBeenCalledWith(
        "correct_service_visit",
        expect.objectContaining({
          target_visit_id: visitRow.id,
          reason: "Forgot to clock out on time",
        }),
      ),
    );
  });

  it("requires a reason before submitting a correction", async () => {
    mockedUseOrganization.mockReturnValue({
      activeOrganizationId: ORG_ID,
      activeOrganization: { displayName: "Acme Care" },
      hasPermission: vi.fn(() => true),
    } as never);
    mockOrgLetterhead();
    mockedRpc.mockResolvedValue({ data: [visitRow], error: null } as never);

    renderPage();
    await openReport(/^Visit records$/);
    await screen.findByText("SCS-V-20260801-4F7K");

    fireEvent.click(screen.getByRole("button", { name: "Correct" }));
    fireEvent.click(screen.getByRole("button", { name: "Save correction" }));

    await waitFor(() =>
      expect(
        screen.getByText("A reason is required to correct a visit."),
      ).toBeInTheDocument(),
    );
  });

  it("shows correction history for a visit", async () => {
    mockedUseOrganization.mockReturnValue({
      activeOrganizationId: ORG_ID,
      activeOrganization: { displayName: "Acme Care" },
      hasPermission: vi.fn(() => true),
    } as never);
    mockOrgLetterhead();
    mockedRpc.mockImplementation((fn: string) => {
      if (fn === "list_service_visits")
        return Promise.resolve({ data: [visitRow], error: null }) as never;
      if (fn === "list_visit_corrections") {
        return Promise.resolve({
          data: [
            {
              id: "correction-1",
              corrected_by_name: "Admin User",
              reason: "Clock-out time was wrong",
              before_snapshot: {
                timeIn: "2026-08-01T13:00:00.000Z",
                timeOut: "2026-08-01T14:00:00.000Z",
                workedMinutes: 60,
                billableMinutes: 60,
              },
              after_snapshot: {
                timeIn: "2026-08-01T13:00:00.000Z",
                timeOut: "2026-08-01T14:30:00.000Z",
                workedMinutes: 90,
                billableMinutes: 90,
              },
              created_at: "2026-08-02T10:00:00.000Z",
            },
          ],
          error: null,
        }) as never;
      }
      return Promise.resolve({ data: [], error: null }) as never;
    });

    renderPage();
    await openReport(/^Visit records$/);
    await screen.findByText("SCS-V-20260801-4F7K");

    fireEvent.click(screen.getByRole("button", { name: "History" }));

    await waitFor(() =>
      expect(
        screen.getByText("Admin User", { exact: false }),
      ).toBeInTheDocument(),
    );
    expect(screen.getByText(/Clock-out time was wrong/)).toBeInTheDocument();
  });

  it("hides Correct and History actions without visits.manage", async () => {
    mockedUseOrganization.mockReturnValue({
      activeOrganizationId: ORG_ID,
      activeOrganization: { displayName: "Acme Care" },
      hasPermission: vi.fn(
        (permission: string) => permission === "visits.read",
      ),
    } as never);
    mockOrgLetterhead();
    mockedRpc.mockResolvedValue({ data: [visitRow], error: null } as never);

    renderPage();
    await openReport(/^Visit records$/);
    await screen.findByText("SCS-V-20260801-4F7K");

    expect(
      screen.queryByRole("button", { name: "Correct" }),
    ).not.toBeInTheDocument();
    expect(
      screen.queryByRole("button", { name: "History" }),
    ).not.toBeInTheDocument();
  });

  it("triggers window.print for the Print action", async () => {
    mockedUseOrganization.mockReturnValue({
      activeOrganizationId: ORG_ID,
      activeOrganization: { displayName: "Acme Care" },
      hasPermission: vi.fn(() => true),
    } as never);
    mockOrgLetterhead();
    mockedRpc.mockResolvedValue({ data: [visitRow], error: null } as never);
    const printSpy = vi.spyOn(window, "print").mockImplementation(() => {});

    renderPage();
    fireEvent.click(
      await screen.findByRole("button", { name: "Print / Save as PDF" }),
    );

    expect(printSpy).toHaveBeenCalled();
  });

  it("hides the three authorization columns by default behind each row's Hours left, and Columns brings them back", async () => {
    window.localStorage.clear();
    allowEverything();
    renderPage();
    await openReport(/^Visit records$/);
    const table = await screen.findByRole("table", { name: "Visit details" });
    const headers = within(table).getAllByRole("columnheader").map((h) => h.textContent);
    expect(headers).toEqual(expect.arrayContaining(["Hours left", "Status", "Actions"]));
    expect(headers).not.toContain("Authorized");
    expect(headers).not.toContain("Billable this month");
    // The same three values sit under the row's Hours left control.
    const row = within(table).getByText("Jamie Smith").closest("tr")!;
    expect(within(row).getByText("Hours left")).toBeInTheDocument();
    expect(row).toHaveTextContent("Hours left: 29 hr");
    expect(row).toHaveTextContent("Billable this month: 11 hr");
    fireEvent.click(screen.getByLabelText("Hours left"));
    expect(within(table).getAllByRole("columnheader").map((h) => h.textContent)).toContain("Hours left");
  });

  it("treats a previously auto-saved full column set as 'never customised', but keeps a real choice", async () => {
    allowEverything();
    window.localStorage.setItem("ogevia.visit-report-columns", JSON.stringify(["visitRef", "client", "caregiver", "service", "date", "time", "worked", "billable", "authorized", "usedMtd", "remaining", "status"]));
    const first = renderPage();
    await openReport(/^Visit records$/);
    let table = await screen.findByRole("table", { name: "Visit details" });
    expect(within(table).getAllByRole("columnheader").map((h) => h.textContent)).toContain("Hours left");
    first.unmount();
    window.localStorage.setItem("ogevia.visit-report-columns", JSON.stringify(["client", "worked", "remaining", "status"]));
    renderPage();
    await openReport(/^Visit records$/);
    table = await screen.findByRole("table", { name: "Visit details" });
    const headers = within(table).getAllByRole("columnheader").map((h) => h.textContent);
    expect(headers).toContain("Hours left");
    // The "Hours left" column replaces the row control of the same name; it is never shown twice.
    expect(headers.filter((h) => h === "Hours left")).toHaveLength(1);
  });

  it("keeps the address in step with the Report selection, so the sidebar highlight follows", async () => {
    window.localStorage.clear();
    allowEverything();
    renderPageWithLocation();
    await openReport(/^Client monthly calendar$/);
    expect(screen.getByTestId("location")).toHaveTextContent("/service-verification/reports?view=calendar");
    await openReport(/^Action needed$/);
    expect(screen.getByTestId("location")).toHaveTextContent("?view=exceptions");
    await openReport(/^Visit records$/);
    // This (Supabase-path) test backend opens on Visits overview, so the visit list is the explicit view here;
    // on the AWS backend the visit list is the default and the address has no ?view=.
    expect(screen.getByTestId("location")).toHaveTextContent("?view=visits");
  });

  it("does not show the date range and filters on the client calendar, where they do not apply", async () => {
    window.localStorage.clear();
    allowEverything();
    renderPage();
    expect(await screen.findByText("Date range")).toBeInTheDocument();
    await openReport(/^Client monthly calendar$/);
    await screen.findByLabelText("Calendar client");
    expect(screen.queryByText("Date range")).toBeNull();
    expect(screen.queryByText(/^Filters/)).toBeNull();
  });

  it("repeats the agency, report, client and period on every printed page, with page numbers", async () => {
    window.localStorage.clear();
    allowEverything();
    renderPage();
    await screen.findByLabelText("Report");
    const runningCss = () => Array.from(document.querySelectorAll("style")).map((e) => e.textContent ?? "").find((t) => t.includes("@top-left")) ?? "";
    await waitFor(() => expect(runningCss()).toContain("Acme Care LLC"));
    const css = runningCss();
    expect(css).toContain("Acme Care LLC");
    expect(css).toContain("Service Verification Report");
    expect(css).toContain("Client: All clients");
    expect(css).toContain("Period: All dates");
    expect(css).toContain('"Page " counter(page) " of " counter(pages)');
  });

  it.each([
    ["test", "TEST — synthetic data only"],
    ["staging", "Environment not verified"],
  ])("a printout from environment %j carries '%s' on every page header and on page one", async (env, label) => {
    window.localStorage.clear();
    allowEverything();
    const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });
    render(
      <MemoryRouter>
        <QueryClientProvider client={queryClient}>
          <EnvironmentProvider marker={resolveEnvironmentMarker(env)}>
            <ServiceVerificationReportsPage />
          </EnvironmentProvider>
        </QueryClientProvider>
      </MemoryRouter>,
    );
    await screen.findByLabelText("Report");
    const runningCss = () => Array.from(document.querySelectorAll("style")).map((e) => e.textContent ?? "").find((t) => t.includes("@top-left")) ?? "";
    await waitFor(() => expect(runningCss()).toContain(label));
    expect(screen.getAllByText(label).length).toBeGreaterThan(0);
  });

  it("production prints no environment line", async () => {
    window.localStorage.clear();
    allowEverything();
    const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });
    render(
      <MemoryRouter>
        <QueryClientProvider client={queryClient}>
          <EnvironmentProvider marker={resolveEnvironmentMarker("production")}>
            <ServiceVerificationReportsPage />
          </EnvironmentProvider>
        </QueryClientProvider>
      </MemoryRouter>,
    );
    await screen.findByLabelText("Report");
    const css = Array.from(document.querySelectorAll("style")).map((e) => e.textContent ?? "").find((t) => t.includes("@top-left")) ?? "";
    expect(css).not.toMatch(/TEST|not verified/);
  });
});
