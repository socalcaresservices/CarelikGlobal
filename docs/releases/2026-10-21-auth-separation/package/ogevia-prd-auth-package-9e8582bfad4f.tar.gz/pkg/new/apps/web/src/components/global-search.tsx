import { useEffect, useRef, useState, type KeyboardEvent } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { Search } from "lucide-react";
import { useOrganization } from "@/providers/organization-provider";
import { supabase } from "@/lib/supabase";

// Backed by global_search(), a security-definer RPC (see
// supabase/migrations/20260719290000_global_search.sql) that unions
// across every table with a meaningful name/label, applying that
// table's own permission check (and own-row carve-out, where one
// exists) per row. Field names match the RPC's return columns, same
// snake_case convention every other RPC result in this app uses.
interface GlobalSearchResultRow {
  result_type: "client" | "caregiver" | "credential" | "authorization" | "incident" | "service" | "applicant";
  entity_id: string;
  title: string;
  subtitle: string | null;
}

const resultTypeLabels: Record<GlobalSearchResultRow["result_type"], string> = {
  client: "Client",
  caregiver: "Caregiver",
  credential: "Credential",
  authorization: "Authorization",
  incident: "Incident",
  service: "Service",
  applicant: "Candidate"
};

// Clients and candidates have stable detail identifiers. Legacy caregiver
// search results still carry a login id, not the Care Team workforce-record id,
// so they route to the Care Team list instead of a broken detail URL.
// the rest route to their list page rather than a fabricated deep link.
// Services are managed inline from the Authorizations page (there's no
// standalone services page), so a service result routes there too.
function routeFor(result: GlobalSearchResultRow): string {
  switch (result.result_type) {
    case "client":
      return `/clients/${result.entity_id}`;
    case "caregiver":
      return "/team";
    case "applicant":
      return `/candidates/${result.entity_id}`;
    case "credential":
      return "/credentials";
    case "authorization":
    case "service":
      return "/authorizations";
    case "incident":
      return "/incidents";
  }
}

export function GlobalSearch() {
  const navigate = useNavigate();
  const { activeOrganizationId } = useOrganization();
  const containerRef = useRef<HTMLDivElement>(null);

  const [query, setQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [highlightedIndex, setHighlightedIndex] = useState(-1);

  useEffect(() => {
    const timeout = setTimeout(() => setDebouncedQuery(query.trim()), 250);
    return () => clearTimeout(timeout);
  }, [query]);

  useEffect(() => {
    setHighlightedIndex(-1);
  }, [debouncedQuery]);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const searchQuery = useQuery({
    queryKey: ["global-search", activeOrganizationId, debouncedQuery],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("global_search", {
        target_organization_id: activeOrganizationId!,
        search_query: debouncedQuery
      });
      if (error) throw error;
      return (data ?? []) as GlobalSearchResultRow[];
    },
    enabled: !!activeOrganizationId && debouncedQuery.length >= 2
  });

  const results = searchQuery.data ?? [];

  function handleSelect(result: GlobalSearchResultRow) {
    setOpen(false);
    setQuery("");
    setHighlightedIndex(-1);
    navigate(routeFor(result));
  }

  const showDropdown = open && debouncedQuery.length >= 2;

  // Arrow keys move a highlighted result up/down (wrapping at the
  // ends), Enter selects whichever is highlighted (or the first result
  // if none is yet), Escape closes the dropdown without navigating.
  function handleKeyDown(event: KeyboardEvent<HTMLInputElement>) {
    if (!showDropdown || results.length === 0) return;

    if (event.key === "ArrowDown") {
      event.preventDefault();
      setHighlightedIndex((current) => (current + 1) % results.length);
    } else if (event.key === "ArrowUp") {
      event.preventDefault();
      setHighlightedIndex((current) => (current <= 0 ? results.length - 1 : current - 1));
    } else if (event.key === "Enter") {
      event.preventDefault();
      const target = results[highlightedIndex] ?? results[0];
      if (target) handleSelect(target);
    } else if (event.key === "Escape") {
      setOpen(false);
      setHighlightedIndex(-1);
    }
  }

  return (
    <div ref={containerRef} className="relative w-full max-w-sm">
      <div className="relative">
        <Search className="pointer-events-none absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
        <input
          type="search"
          aria-label="Search everything"
          placeholder="Search clients, caregivers, credentials…"
          value={query}
          onChange={(event) => {
            setQuery(event.target.value);
            setOpen(true);
          }}
          onFocus={() => setOpen(true)}
          onKeyDown={handleKeyDown}
          role="combobox"
          aria-expanded={showDropdown}
          aria-controls="global-search-results"
          aria-autocomplete="list"
          className="w-full rounded-lg border border-slate-200 py-1.5 pl-8 pr-3 text-sm text-slate-900"
        />
      </div>
      {showDropdown ? (
        <div className="absolute z-10 mt-1 w-full rounded-lg border border-slate-200 bg-og-card shadow-lg">
          {searchQuery.isLoading ? (
            <p className="px-3 py-2 text-sm text-slate-500">Searching…</p>
          ) : searchQuery.isError ? (
            <p className="px-3 py-2 text-sm text-red-700">Could not search.</p>
          ) : results.length === 0 ? (
            <p className="px-3 py-2 text-sm text-slate-500">No matches for "{debouncedQuery}".</p>
          ) : (
            <ul id="global-search-results" role="listbox" className="max-h-80 overflow-y-auto py-1">
              {results.map((result, index) => (
                <li key={`${result.result_type}-${result.entity_id}`} role="option" aria-selected={index === highlightedIndex}>
                  <button
                    type="button"
                    onClick={() => handleSelect(result)}
                    onMouseEnter={() => setHighlightedIndex(index)}
                    className={`flex w-full flex-col items-start px-3 py-2 text-left ${
                      index === highlightedIndex ? "bg-slate-50" : "hover:bg-slate-50"
                    }`}
                  >
                    <span className="text-[11px] font-medium uppercase tracking-wide text-slate-400">
                      {resultTypeLabels[result.result_type]}
                    </span>
                    <span className="text-sm text-slate-900">{result.title}</span>
                    {result.subtitle ? (
                      <span className="text-xs text-slate-500">{result.subtitle}</span>
                    ) : null}
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      ) : null}
    </div>
  );
}
