import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { afterEach, describe, expect, it, vi } from "vitest";
import { useOrganization } from "@/providers/organization-provider";
import { supabase } from "@/lib/supabase";
import { CredentialsPage } from "./credentials-page";

vi.mock("@/providers/organization-provider", () => ({ useOrganization: vi.fn() }));
vi.mock("@/lib/supabase", () => ({
  supabase: {
    rpc: vi.fn(),
    from: vi.fn()
  }
}));

const mockedUseOrganization = vi.mocked(useOrganization);
const mockedRpc = vi.mocked(supabase.rpc);

const ORG_ID = "11111111-1111-4111-8111-111111111111";
const CAREGIVER_ID = "44444444-4444-4444-8444-444444444444";

function baseOrganization() {
  return {
    organizations: [],
    activeOrganization: {
      id: ORG_ID,
      slug: "acme",
      legalName: "Acme LLC",
      displayName: "Acme",
      status: "active" as const,
      timezone: "America/Los_Angeles"
    },
    activeOrganizationId: ORG_ID,
    setActiveOrganizationId: vi.fn(),
    role: "organization_admin" as const,
    isPlatformOwner: false,
    hasPermission: vi.fn(),
    loading: false
  };
}

function renderPage(initialPath = "/credentials") {
  const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return render(
    <MemoryRouter initialEntries={[initialPath]}>
      <QueryClientProvider client={queryClient}>
        <CredentialsPage />
      </QueryClientProvider>
    </MemoryRouter>
  );
}

describe("CredentialsPage", () => {
  afterEach(() => {
    vi.clearAllMocks();
  });

  it("hides the add form and shows an own-credentials note without credentials.read", async () => {
    mockedUseOrganization.mockReturnValue({
      ...baseOrganization(),
      hasPermission: vi.fn(() => false)
    });
    mockedRpc.mockResolvedValue({ data: [], error: null } as never);

    renderPage();

    expect(screen.getByText("Showing only your own credentials.")).toBeInTheDocument();
    expect(screen.queryByText("Add a credential")).not.toBeInTheDocument();
  });

  it("lists credentials with a status badge", async () => {
    mockedUseOrganization.mockReturnValue({
      ...baseOrganization(),
      hasPermission: vi.fn(() => true)
    });
    mockedRpc.mockImplementation((fn: string) => {
      if (fn === "list_caregiver_credentials") {
        return Promise.resolve({
          data: [
            {
              id: "55555555-5555-4555-8555-555555555555",
              caregiver_user_id: CAREGIVER_ID,
              caregiver_name: "Sam Caregiver",
              credential_type: "CPR Certification",
              issued_date: "2026-01-01",
              expires_at: "2020-01-01",
              notes: null
            }
          ],
          error: null
        }) as never;
      }
      return Promise.resolve({ data: [], error: null }) as never;
    });

    renderPage();

    await waitFor(() => expect(screen.getByText("Sam Caregiver")).toBeInTheDocument());
    expect(screen.getByText("CPR Certification")).toBeInTheDocument();
    expect(screen.getByText("Expired", { selector: "span" })).toBeInTheDocument();
  });

  it("exports filtered credentials as a CSV download", async () => {
    mockedUseOrganization.mockReturnValue({
      ...baseOrganization(),
      hasPermission: vi.fn(() => true)
    });
    mockedRpc.mockImplementation((fn: string) => {
      if (fn === "list_caregiver_credentials") {
        return Promise.resolve({
          data: [
            {
              id: "55555555-5555-4555-8555-555555555555",
              caregiver_user_id: CAREGIVER_ID,
              caregiver_name: "Sam Caregiver",
              credential_type: "CPR Certification",
              issued_date: "2026-01-01",
              expires_at: "2020-01-01",
              notes: null
            }
          ],
          error: null
        }) as never;
      }
      return Promise.resolve({ data: [], error: null }) as never;
    });

    renderPage();
    await waitFor(() => expect(screen.getByText("Sam Caregiver")).toBeInTheDocument());

    const clickSpy = vi.spyOn(HTMLAnchorElement.prototype, "click").mockImplementation(() => {});
    fireEvent.click(screen.getByRole("button", { name: "Export filtered CSV" }));

    expect(clickSpy).toHaveBeenCalledTimes(1);
    clickSpy.mockRestore();
  });

  it("adds a new credential", async () => {
    mockedUseOrganization.mockReturnValue({
      ...baseOrganization(),
      hasPermission: vi.fn(() => true)
    });
    mockedRpc.mockImplementation((fn: string) => {
      if (fn === "list_organization_members") {
        return Promise.resolve({
          data: [{ user_id: CAREGIVER_ID, display_name: "Sam Caregiver", status: "active" }],
          error: null
        }) as never;
      }
      return Promise.resolve({ data: null, error: null }) as never;
    });

    renderPage();
    await waitFor(() => expect(screen.getByText("Add a credential")).toBeInTheDocument());

    fireEvent.focus(screen.getByLabelText("Caregiver"));
    await waitFor(() => expect(screen.getByRole("option", { name: "Sam Caregiver" })).toBeInTheDocument());
    fireEvent.mouseDown(screen.getByRole("option", { name: "Sam Caregiver" }));

    fireEvent.change(screen.getByLabelText("Credential"), { target: { value: "TB Test" } });
    fireEvent.click(screen.getByRole("button", { name: "Add credential" }));

    await waitFor(() =>
      expect(mockedRpc).toHaveBeenCalledWith(
        "add_caregiver_credential",
        expect.objectContaining({
          target_organization_id: ORG_ID,
          target_user_id: CAREGIVER_ID,
          new_credential_type: "TB Test"
        })
      )
    );
  });

  it("pre-fills and locks the caregiver field when arriving with ?caregiverId=", async () => {
    mockedUseOrganization.mockReturnValue({
      ...baseOrganization(),
      hasPermission: vi.fn(() => true)
    });
    mockedRpc.mockImplementation((fn: string) => {
      if (fn === "list_organization_members") {
        return Promise.resolve({
          data: [{ user_id: CAREGIVER_ID, display_name: "Sam Caregiver", status: "active" }],
          error: null
        }) as never;
      }
      return Promise.resolve({ data: [], error: null }) as never;
    });

    renderPage(`/credentials?caregiverId=${CAREGIVER_ID}`);

    await waitFor(() => expect(screen.getByLabelText("Caregiver")).toBeDisabled());
    await waitFor(() => expect(screen.getByLabelText("Caregiver")).toHaveValue("Sam Caregiver"));
  });

  it("soft-deletes a credential via Remove", async () => {
    mockedUseOrganization.mockReturnValue({
      ...baseOrganization(),
      hasPermission: vi.fn(() => true)
    });
    mockedRpc.mockImplementation((fn: string) => {
      if (fn === "list_caregiver_credentials") {
        return Promise.resolve({
          data: [
            {
              id: "55555555-5555-4555-8555-555555555555",
              caregiver_user_id: CAREGIVER_ID,
              caregiver_name: "Sam Caregiver",
              credential_type: "CPR Certification",
              issued_date: null,
              expires_at: null,
              notes: null
            }
          ],
          error: null
        }) as never;
      }
      if (fn === "delete_caregiver_credential") {
        return Promise.resolve({ data: null, error: null }) as never;
      }
      return Promise.resolve({ data: [], error: null }) as never;
    });

    renderPage();
    await waitFor(() => expect(screen.getByText("Remove")).toBeInTheDocument());

    fireEvent.click(screen.getByText("Remove"));

    await waitFor(() =>
      expect(mockedRpc).toHaveBeenCalledWith("delete_caregiver_credential", {
        target_credential_id: "55555555-5555-4555-8555-555555555555"
      })
    );
  });
});
