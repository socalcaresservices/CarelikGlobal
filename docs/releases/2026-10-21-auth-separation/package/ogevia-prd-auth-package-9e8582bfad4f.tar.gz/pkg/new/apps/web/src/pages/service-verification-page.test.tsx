import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { useAuth } from "@carelik/auth";
import { useOrganization } from "@/providers/organization-provider";
import { supabase } from "@/lib/supabase";
import { ServiceVerificationPage } from "./service-verification-page";

vi.mock("@carelik/auth", () => ({ useAuth: vi.fn() }));
vi.mock("@/providers/organization-provider", () => ({
  useOrganization: vi.fn(),
}));
vi.mock("@/lib/supabase", () => ({
  supabase: {
    rpc: vi.fn(),
    storage: { from: vi.fn() },
  },
}));

const mockedUseAuth = vi.mocked(useAuth);
const mockedUseOrganization = vi.mocked(useOrganization);
const mockedRpc = vi.mocked(supabase.rpc);
const mockedStorageFrom = vi.mocked(supabase.storage.from);

const ORG_ID = "11111111-1111-4111-8111-111111111111";
const USER_ID = "44444444-4444-4444-8444-444444444444";
const CLIENT_ID = "77777777-7777-4777-8777-777777777777";
const SECOND_CLIENT_ID = "77777777-7777-4777-8777-777777777778";
const SERVICE_ID = "88888888-8888-4888-8888-888888888888";
const VISIT_ID = "66666666-6666-4666-8666-666666666666";

function authUser() {
  return {
    user: { id: USER_ID } as never,
    session: {} as never,
    loading: false,
    provider: "supabase" as const,
    error: null,
    sessionExpired: false,
    signIn: vi.fn(),
    completeSignIn: vi.fn(),
    getAccessToken: vi.fn(),
    signInWithGithub: vi.fn(),
    signInWithPassword: vi.fn(),
    resetPasswordForEmail: vi.fn(),
    updatePassword: vi.fn(),
    signOut: vi.fn(),
  };
}

function baseOrganization() {
  return {
    activeOrganizationId: ORG_ID,
    activeOrganization: { id: ORG_ID, displayName: "Acme Care", logoUrl: null },
    hasPermission: vi.fn(() => false),
  };
}

const assignedClients = [
  {
    client_id: CLIENT_ID,
    client_code: "C-104",
    next_scheduled_starts_at: "2026-08-24T21:30:00.000Z",
    next_scheduled_ends_at: "2026-08-24T23:30:00.000Z",
    active_service_count: 1,
  },
  {
    client_id: SECOND_CLIENT_ID,
    client_code: "C-207",
    next_scheduled_starts_at: "2026-08-25T00:00:00.000Z",
    next_scheduled_ends_at: "2026-08-25T02:00:00.000Z",
    active_service_count: 9,
  },
];

const authorizedService = {
  service_id: SERVICE_ID,
  service_code: "862",
  service_name: "Respite Care",
  service_color: "#4f46e5",
  authorization_id: "99999999-9999-4999-8999-999999999999",
  max_monthly_hours: 80,
  hours_used_this_month: 24.5,
  hours_scheduled_this_month: 2,
};

const activeVisit = {
  visit_id: VISIT_ID,
  visit_number: "OGEV-V-20260824-AB12",
  client_code: "C-104",
  service_code: "862",
  service_name: "Respite Care",
  scheduled_starts_at: "2026-08-24T21:30:00.000Z",
  scheduled_ends_at: "2026-08-24T23:30:00.000Z",
  time_in: "2026-08-24T21:30:00.000Z",
  time_out: null,
  worked_minutes: null,
  visit_status: "draft",
  max_monthly_hours: 80,
  confirmed_minutes_this_month: 1470,
};

function renderPage() {
  const queryClient = new QueryClient({
    defaultOptions: { queries: { retry: false } },
  });
  return render(
    <QueryClientProvider client={queryClient}>
      <ServiceVerificationPage />
    </QueryClientProvider>,
  );
}

function mockRpcImplementation(overrides: Record<string, unknown> = {}) {
  mockedRpc.mockImplementation((fn: string) => {
    if (fn in overrides) return Promise.resolve(overrides[fn]) as never;
    if (fn === "get_active_service_visit_v3")
      return Promise.resolve({ data: [], error: null }) as never;
    if (fn === "list_assigned_visit_clients")
      return Promise.resolve({ data: assignedClients, error: null }) as never;
    if (fn === "list_authorized_services_for_client") {
      return Promise.resolve({
        data: [authorizedService],
        error: null,
      }) as never;
    }
    if (fn === "list_scheduled_shifts_for_visit")
      return Promise.resolve({ data: [], error: null }) as never;
    if (fn === "start_ad_hoc_service_visit")
      return Promise.resolve({ data: VISIT_ID, error: null }) as never;
    return Promise.resolve({ data: null, error: null }) as never;
  });
}

async function openConfirmation() {
  fireEvent.click(await screen.findByRole("button", { name: /End visit/ }));
  await screen.findByRole("heading", {
    name: "Verify visit details",
  });
}

describe("ServiceVerificationPage v3", () => {
  beforeEach(() => {
    mockedUseAuth.mockReturnValue(authUser());
    mockedUseOrganization.mockReturnValue(baseOrganization() as never);
    HTMLCanvasElement.prototype.getContext = vi.fn(() => null) as never;
    HTMLCanvasElement.prototype.toDataURL = vi.fn(
      () => "data:image/png;base64,Zm9v",
    );
    HTMLCanvasElement.prototype.setPointerCapture = vi.fn();
  });

  afterEach(() => {
    vi.clearAllMocks();
    vi.useRealTimers();
    vi.unstubAllGlobals();
  });

  it("lists today's scheduled visits by client code and never renders a client legal name", async () => {
    mockRpcImplementation();
    renderPage();

    expect(
      await screen.findByRole("heading", { name: "Today's visits" }),
    ).toBeInTheDocument();
    const scheduled = await screen.findByRole("list", {
      name: "Scheduled today",
    });
    expect(scheduled).toHaveTextContent("Client C-104");
    expect(scheduled).toHaveTextContent("2:30 PM–4:30 PM");
    expect(scheduled).toHaveTextContent("Client C-207");
    expect(scheduled).toHaveTextContent("9 active services");
    expect(screen.queryByText("Darby Crash")).not.toBeInTheDocument();
    expect(
      screen.getByText("Visit Verification · Verificación de Visita"),
    ).toBeInTheDocument();
    expect(screen.getByText("Acme Care")).toBeInTheDocument();
    expect(screen.queryByText(/EVV|GPS/i)).not.toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Start visit/ })).toBeDisabled();

    expect(mockedRpc).toHaveBeenCalledWith("list_assigned_visit_clients", {
      target_organization_id: ORG_ID,
    });
  });

  it("separates assigned clients with no visit today and warns before an unscheduled start", async () => {
    mockRpcImplementation({
      list_assigned_visit_clients: {
        data: [
          {
            ...assignedClients[0],
            next_scheduled_starts_at: null,
            next_scheduled_ends_at: null,
          },
        ],
        error: null,
      },
    });
    renderPage();

    expect(
      await screen.findByText("You have no visits scheduled for today."),
    ).toBeInTheDocument();
    const other = screen.getByRole("list", { name: "Other assigned clients" });
    expect(other).toHaveTextContent("Not scheduled today");

    fireEvent.click(screen.getByRole("button", { name: /Client C-104/ }));
    const details = await screen.findByRole("group", { name: "Visit details" });
    expect(details).toHaveTextContent("Unscheduled visit");
    expect(details).toHaveTextContent(
      "This client is not on your schedule today.",
    );
    await waitFor(() =>
      expect(screen.getByRole("button", { name: /Start visit/ })).toBeEnabled(),
    );
  });

  it("shows client, service, date and scheduled times, then starts exactly that client-service pair", async () => {
    mockRpcImplementation();
    renderPage();

    fireEvent.click(await screen.findByRole("button", { name: /Client C-104/ }));
    expect(
      screen.getByRole("button", { name: /Client C-104/ }),
    ).toHaveAttribute("aria-pressed", "true");
    const details = await screen.findByRole("group", { name: "Visit details" });
    await waitFor(() => expect(details).toHaveTextContent("862 · Respite Care"));
    expect(details).toHaveTextContent("ClientC-104");
    expect(details).toHaveTextContent("08/24/2026");
    expect(details).toHaveTextContent("2:30 PM–4:30 PM");
    // One service: no picker to operate.
    expect(
      screen.queryByLabelText("Service for this visit"),
    ).not.toBeInTheDocument();

    fireEvent.click(screen.getByRole("button", { name: /Start visit/ }));
    await waitFor(() =>
      expect(mockedRpc).toHaveBeenCalledWith("start_ad_hoc_service_visit", {
        target_organization_id: ORG_ID,
        target_client_id: CLIENT_ID,
        target_service_id: SERVICE_ID,
        visit_task_categories: [],
        visit_service_notes: null,
      }),
    );
  });

  it("shows the server's Left to record and names how the office Hours left differs (0079)", async () => {
    mockRpcImplementation({
      list_authorized_services_for_client: {
        data: [{ ...authorizedService, hours_used_this_month: 24.5, left_to_record_minutes: 3330, hours_left_minutes: 3120, office_pending_minutes: 130, office_reserved_minutes: 80 }],
        error: null,
      },
    });
    renderPage();
    fireEvent.click(await screen.findByRole("button", { name: /Client C-104/ }));
    const note = await screen.findByTestId("caregiver-balance-note");
    expect(note).toHaveTextContent("The office Hours left is lower by 1 hr 20 min Reserved for scheduled visits and 2 hr 10 min Pending.");
    expect(screen.getByText("Left to record").previousElementSibling).toHaveTextContent("55 hr 30 min"); // the server's figure, not recomputed here
  });

  it("requires an explicit choice when a client has nine services", async () => {
    const services = Array.from({ length: 9 }, (_, index) => ({
      ...authorizedService,
      service_id: `88888888-8888-4888-8888-88888888888${index}`,
      service_code: `S-${index + 1}`,
      service_name: `Service ${index + 1}`,
    }));
    mockRpcImplementation({
      list_authorized_services_for_client: { data: services, error: null },
    });
    renderPage();

    fireEvent.click(await screen.findByRole("button", { name: /Client C-207/ }));
    expect(
      await screen.findByText(
        "This client has 9 active services. Choose the one you are providing.",
      ),
    ).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Start visit/ })).toBeDisabled();

    fireEvent.change(screen.getByLabelText("Service for this visit"), {
      target: { value: services[8]!.service_id },
    });
    expect(screen.getByRole("button", { name: /Start visit/ })).toBeEnabled();
    expect(
      screen.getByRole("group", { name: "Visit details" }),
    ).toHaveTextContent("S-9 · Service 9");
  });

  it("preselects the service of today's scheduled visit and warns when it is changed", async () => {
    const services = Array.from({ length: 3 }, (_, index) => ({
      ...authorizedService,
      service_id: `88888888-8888-4888-8888-88888888888${index}`,
      service_code: `S-${index + 1}`,
      service_name: `Service ${index + 1}`,
    }));
    mockRpcImplementation({
      list_assigned_visit_clients: {
        data: [{ ...assignedClients[1], active_service_count: 3, next_scheduled_service_id: services[1]!.service_id }],
        error: null,
      },
      list_authorized_services_for_client: { data: services, error: null },
    });
    renderPage();

    fireEvent.click(await screen.findByRole("button", { name: /Client C-207/ }));
    await waitFor(() =>
      expect(screen.getByLabelText("Service for this visit")).toHaveValue(services[1]!.service_id),
    );
    expect(screen.getByText(/Scheduled today: S-2 · Service 2/)).toBeInTheDocument();
    expect(screen.queryByText(/not the scheduled service/)).not.toBeInTheDocument();
    expect(screen.getByRole("group", { name: "Visit details" })).toHaveTextContent("S-2 · Service 2");

    // A deliberate change is kept, and flagged.
    fireEvent.change(screen.getByLabelText("Service for this visit"), {
      target: { value: services[2]!.service_id },
    });
    expect(screen.getByLabelText("Service for this visit")).toHaveValue(services[2]!.service_id);
    expect(screen.getByRole("status")).toHaveTextContent(
      "This is not the scheduled service. The visit will not be linked to today's scheduled visit.",
    );

    fireEvent.change(screen.getByLabelText("Service for this visit"), {
      target: { value: services[1]!.service_id },
    });
    fireEvent.click(screen.getByRole("button", { name: /Start visit/ }));
    await waitFor(() =>
      expect(mockedRpc).toHaveBeenCalledWith("start_ad_hoc_service_visit", expect.objectContaining({
        target_client_id: SECOND_CLIENT_ID,
        target_service_id: services[1]!.service_id,
      })),
    );
  });

  it("asks for an explicit choice when the backend does not report the scheduled service", async () => {
    const services = Array.from({ length: 2 }, (_, index) => ({
      ...authorizedService,
      service_id: `88888888-8888-4888-8888-88888888888${index}`,
      service_code: `S-${index + 1}`,
      service_name: `Service ${index + 1}`,
    }));
    mockRpcImplementation({
      list_authorized_services_for_client: { data: services, error: null },
    });
    renderPage();
    fireEvent.click(await screen.findByRole("button", { name: /Client C-207/ }));
    expect(await screen.findByText(/Choose the one you are providing/)).toBeInTheDocument();
    expect(screen.getByLabelText("Service for this visit")).toHaveValue("");
    expect(screen.getByRole("button", { name: /Start visit/ })).toBeDisabled();
  });

  it("blocks the start when the selected client has no active authorized service", async () => {
    mockRpcImplementation({
      list_authorized_services_for_client: { data: [], error: null },
    });
    renderPage();

    fireEvent.click(await screen.findByRole("button", { name: /Client C-104/ }));

    expect(
      await screen.findByText(
        "No active service authorization is available for Client C-104.",
      ),
    ).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Start visit/ })).toBeDisabled();
  });

  it("shows one locked live visit with no time-edit or client-name controls", async () => {
    const timeIn = new Date(Date.now() - 5 * 60_000).toISOString();
    mockRpcImplementation({
      get_active_service_visit_v3: {
        data: [{ ...activeVisit, time_in: timeIn }],
        error: null,
      },
    });
    renderPage();

    expect(
      await screen.findByRole("heading", { name: "Visit in progress" }),
    ).toBeInTheDocument();
    expect(screen.getByText("C-104")).toBeInTheDocument();
    expect(
      screen.getByText("Client and service are locked."),
    ).toBeInTheDocument();
    expect(
      screen.getByRole("button", { name: /End visit/ }),
    ).toBeInTheDocument();
    expect(screen.queryByLabelText(/time in/i)).not.toBeInTheDocument();
    expect(screen.queryByText("Darby Crash")).not.toBeInTheDocument();
  });

  it("shows the linked shift's scheduled window during the visit and at confirmation", async () => {
    const timeIn = new Date(Date.now() - 5 * 60_000).toISOString();
    mockRpcImplementation({
      get_active_service_visit_v3: {
        data: [{ ...activeVisit, time_in: timeIn }],
        error: null,
      },
      end_service_visit: {
        data: [
          {
            visit_id: VISIT_ID,
            worked_minutes: 120,
            time_in: "2026-08-24T21:30:00.000Z",
            time_out: "2026-08-24T23:30:00.000Z",
          },
        ],
        error: null,
      },
    });
    renderPage();

    await screen.findByRole("heading", { name: "Visit in progress" });
    // 21:30Z-23:30Z is 2:30-4:30 PM Pacific (PDT).
    expect(screen.getByText(/Scheduled shift:/)).toBeInTheDocument();
    expect(screen.getByText(/^2:30\sPM–4:30\sPM$/)).toBeInTheDocument();

    await openConfirmation();
    const scheduled = screen.getByText("Scheduled shift");
    expect(scheduled.nextElementSibling?.textContent).toMatch(
      /^2:30\sPM–4:30\sPM$/,
    );
  });

  it("says plainly when a visit is not linked to a scheduled shift", async () => {
    const timeIn = new Date(Date.now() - 5 * 60_000).toISOString();
    mockRpcImplementation({
      get_active_service_visit_v3: {
        data: [
          {
            ...activeVisit,
            time_in: timeIn,
            scheduled_starts_at: null,
            scheduled_ends_at: null,
          },
        ],
        error: null,
      },
    });
    renderPage();

    await screen.findByRole("heading", { name: "Visit in progress" });
    expect(
      screen.getByText("Unscheduled visit"),
    ).toBeInTheDocument();
    expect(screen.queryByText(/Scheduled shift:/)).not.toBeInTheDocument();
  });

  it("tells the caregiver and client when the agency entered the Time Out", async () => {
    mockRpcImplementation({
      get_active_service_visit_v3: {
        data: [
          {
            ...activeVisit,
            visit_status: "awaiting_signature",
            time_out: "2026-08-24T23:30:00.000Z",
            worked_minutes: 120,
            time_out_entered_by_manager: true,
          },
        ],
        error: null,
      },
    });
    renderPage();

    await screen.findByRole("heading", { name: "Verify visit details" });
    expect(screen.getByText(/entered by your agency because the visit was not signed out/)).toBeInTheDocument();
  });

  it("recovers an ended visit directly into confirmation after a refresh", async () => {
    mockRpcImplementation({
      get_active_service_visit_v3: {
        data: [
          {
            ...activeVisit,
            visit_status: "awaiting_signature",
            time_out: "2026-08-24T23:30:00.000Z",
            worked_minutes: 120,
          },
        ],
        error: null,
      },
    });
    renderPage();

    expect(
      await screen.findByRole("heading", { name: "Verify visit details" }),
    ).toBeInTheDocument();
    expect(screen.getByText("C-104")).toBeInTheDocument();
    expect(screen.getByText("2 hr")).toBeInTheDocument();
  });

  it("ends with a server timestamp and captures a client signature", async () => {
    mockRpcImplementation({
      get_active_service_visit_v3: { data: [activeVisit], error: null },
      end_service_visit: {
        data: [
          {
            visit_id: VISIT_ID,
            worked_minutes: 120,
            time_in: "2026-08-24T21:30:00.000Z",
            time_out: "2026-08-24T23:30:00.000Z",
          },
        ],
        error: null,
      },
      confirm_service_visit: {
        data: [
          {
            status: "signed",
            authorization_status: "within_authorization",
            worked_minutes: 120,
            billable_minutes: 120,
            month_to_date_minutes: 1590,
            remaining_minutes: 3210,
          },
        ],
        error: null,
      },
    });
    const upload = vi
      .fn()
      .mockResolvedValue({ data: { path: "x" }, error: null });
    mockedStorageFrom.mockReturnValue({ upload } as never);
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue({
        blob: () =>
          Promise.resolve(new Blob(["fake-png"], { type: "image/png" })),
      }),
    );
    renderPage();

    await openConfirmation();
    const canvas = screen.getByLabelText("Client or guardian signature");
    fireEvent.pointerDown(canvas, { pointerId: 1, clientX: 10, clientY: 10 });
    fireEvent.pointerMove(canvas, { pointerId: 1, clientX: 20, clientY: 20 });
    fireEvent.pointerUp(canvas, { pointerId: 1, clientX: 20, clientY: 20 });
    fireEvent.click(screen.getByRole("button", { name: /Confirm visit/ }));

    await waitFor(() =>
      expect(upload).toHaveBeenCalledWith(
        `${ORG_ID}/${VISIT_ID}/client-signature.png`,
        expect.anything(),
        { contentType: "image/png", upsert: true },
      ),
    );
    expect(mockedRpc).toHaveBeenCalledWith("confirm_service_visit", {
      target_visit_id: VISIT_ID,
      signer_role: "client",
      confirmation_method: "draw",
      signature_storage_path: `${ORG_ID}/${VISIT_ID}/client-signature.png`,
      typed_signer_name: null,
      signer_relationship: null,
      confirmation_reason: null,
    });
    expect(
      await screen.findByRole("heading", { name: "Visit saved" }),
    ).toBeInTheDocument();
    const outcome = screen.getByLabelText("Visit result");
    expect(outcome).toHaveTextContent("Worked2 hr");
    expect(outcome).toHaveTextContent("Billable2 hr");
    expect(outcome).toHaveTextContent("BillingBilling ready");
    expect(outcome).toHaveTextContent("Billing ready does not mean billed.");
  });

  it("saves a no-signer visit as unverified and not billable", async () => {
    mockRpcImplementation({
      get_active_service_visit_v3: { data: [activeVisit], error: null },
      end_service_visit: {
        data: [
          {
            visit_id: VISIT_ID,
            worked_minutes: 120,
            time_in: "2026-08-24T21:30:00.000Z",
            time_out: "2026-08-24T23:30:00.000Z",
          },
        ],
        error: null,
      },
      confirm_service_visit: {
        data: [
          {
            status: "administrator_review",
            authorization_status: "within_authorization",
            worked_minutes: 120,
            billable_minutes: 0,
            month_to_date_minutes: 1470,
            remaining_minutes: 3330,
          },
        ],
        error: null,
      },
    });
    renderPage();

    await openConfirmation();
    fireEvent.click(screen.getByRole("button", { name: /Unable to obtain confirmation/ }));
    expect(
      screen.getByRole("button", { name: "Submit for manager review" }),
    ).toBeDisabled();
    fireEvent.change(screen.getByLabelText("Why is manager review needed?"), {
      target: { value: "Technical problem prevented signing" },
    });
    fireEvent.change(screen.getByLabelText("Brief explanation"), {
      target: { value: "The signature pad did not respond" },
    });
    fireEvent.click(
      screen.getByRole("button", { name: "Submit for manager review" }),
    );

    await waitFor(() =>
      expect(mockedRpc).toHaveBeenCalledWith("confirm_service_visit", {
        target_visit_id: VISIT_ID,
        signer_role: "client",
        confirmation_method: "unable_to_confirm",
        signature_storage_path: null,
        typed_signer_name: null,
        signer_relationship: null,
        confirmation_reason:
          "Technical problem prevented signing: The signature pad did not respond",
      }),
    );
    expect(mockedStorageFrom).not.toHaveBeenCalled();
    expect(
      await screen.findByRole("heading", { name: "Saved for manager review" }),
    ).toBeInTheDocument();
    expect(
      screen.getByText(/not counted as confirmed or billable/i),
    ).toBeInTheDocument();
    const outcome = screen.getByLabelText("Visit result");
    expect(outcome).toHaveTextContent("Billable0 min");
    expect(outcome).toHaveTextContent("BillingNeeds manager review");
    expect(outcome).not.toHaveTextContent("Billing ready");
  });

  it("does not mislabel a signed visit when authorization leaves zero billable minutes", async () => {
    mockRpcImplementation({
      get_active_service_visit_v3: { data: [activeVisit], error: null },
      end_service_visit: {
        data: [
          {
            visit_id: VISIT_ID,
            worked_minutes: 120,
            time_in: "2026-08-24T21:30:00.000Z",
            time_out: "2026-08-24T23:30:00.000Z",
          },
        ],
        error: null,
      },
      confirm_service_visit: {
        data: [
          {
            status: "administrator_review",
            authorization_status: "exceeds_authorization",
            worked_minutes: 120,
            billable_minutes: 0,
            month_to_date_minutes: 4800,
            remaining_minutes: 0,
          },
        ],
        error: null,
      },
    });
    mockedStorageFrom.mockReturnValue({
      upload: vi.fn().mockResolvedValue({ data: { path: "x" }, error: null }),
    } as never);
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue({
        blob: () =>
          Promise.resolve(new Blob(["fake-png"], { type: "image/png" })),
      }),
    );
    renderPage();

    await openConfirmation();
    const canvas = screen.getByLabelText("Client or guardian signature");
    fireEvent.pointerDown(canvas, { pointerId: 1, clientX: 10, clientY: 10 });
    fireEvent.pointerMove(canvas, { pointerId: 1, clientX: 20, clientY: 20 });
    fireEvent.pointerUp(canvas, { pointerId: 1, clientX: 20, clientY: 20 });
    fireEvent.click(screen.getByRole("button", { name: /Confirm visit/ }));

    expect(
      await screen.findByRole("heading", { name: "Visit saved" }),
    ).toBeInTheDocument();
    expect(
      screen.getByText(/Client confirmation was recorded/i),
    ).toBeInTheDocument();
    expect(
      screen.queryByText(/No client confirmation was recorded/i),
    ).not.toBeInTheDocument();
  });

  it("blocks the screen if the active-visit safety check fails", async () => {
    mockRpcImplementation({
      get_active_service_visit_v3: {
        data: null,
        error: { message: "network down" },
      },
    });
    renderPage();

    expect(
      await screen.findByText(
        "The sign-in sheet could not safely check for an open visit.",
      ),
    ).toBeInTheDocument();
    expect(
      screen.queryByRole("button", { name: /Start visit/ }),
    ).not.toBeInTheDocument();
  });

  it("shows a sign-in prompt when logged out", () => {
    mockedUseAuth.mockReturnValue({ ...authUser(), user: null });
    mockRpcImplementation();
    renderPage();
    expect(
      screen.getByText("Sign in to use Service Verification."),
    ).toBeInTheDocument();
    expect(mockedRpc).not.toHaveBeenCalled();
  });
});
